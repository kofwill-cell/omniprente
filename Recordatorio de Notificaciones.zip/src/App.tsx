import { useState, useEffect } from 'react';
import { WidgetView } from './components/WidgetView';
import { GoalsManager } from './components/GoalsManager';
import { Dashboard } from './components/Dashboard';
import { Home, Target, BarChart3, Settings, Bell } from 'lucide-react';
import { 
  sendNotification, 
  registerServiceWorker, 
  isMobile, 
  isIOS, 
  isInstalledPWA
} from './utils/notifications';

export interface Goal {
  id: string;
  title: string;
  description: string;
  category: string;
  color: string;
  icon: string;
  progress: number;
  target: number;
  unit: string;
  reminders: GoalReminder[];
  enabled: boolean;
  createdAt: string;
}

export interface GoalReminder {
  id: string;
  time: string;
  message: string;
  recurrence: 'once' | 'daily' | 'weekly' | 'monthly';
  enabled: boolean;
  lastNotified?: string;
  notificationHistory: string[];
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'widget' | 'goals' | 'dashboard' | 'settings'>('widget');
  const [goals, setGoals] = useState<Goal[]>([]);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  
  useEffect(() => {
    // Cargar metas del localStorage
    const stored = localStorage.getItem('goals-app');
    if (stored) {
      setGoals(JSON.parse(stored));
    } else {
      // Datos de ejemplo
      const exampleGoals: Goal[] = [
        {
          id: '1',
          title: 'Beber 8 vasos de agua',
          description: 'Mantenerme hidratado durante el día',
          category: 'Salud',
          color: '#3b82f6',
          icon: '💧',
          progress: 3,
          target: 8,
          unit: 'vasos',
          enabled: true,
          createdAt: new Date().toISOString(),
          reminders: [
            {
              id: 'r1',
              time: '09:00',
              message: 'Toma tu primer vaso de agua',
              recurrence: 'daily',
              enabled: true,
              notificationHistory: []
            },
            {
              id: 'r2',
              time: '12:00',
              message: 'Hora de hidratarte',
              recurrence: 'daily',
              enabled: true,
              notificationHistory: []
            },
            {
              id: 'r3',
              time: '16:00',
              message: 'Bebe agua',
              recurrence: 'daily',
              enabled: true,
              notificationHistory: []
            },
            {
              id: 'r4',
              time: '20:00',
              message: 'Último vaso del día',
              recurrence: 'daily',
              enabled: true,
              notificationHistory: []
            }
          ]
        },
        {
          id: '2',
          title: 'Hacer ejercicio',
          description: '30 minutos de actividad física',
          category: 'Fitness',
          color: '#10b981',
          icon: '🏃',
          progress: 1,
          target: 1,
          unit: 'sesión',
          enabled: true,
          createdAt: new Date().toISOString(),
          reminders: [
            {
              id: 'r5',
              time: '07:00',
              message: 'Hora de ejercitarte',
              recurrence: 'daily',
              enabled: true,
              notificationHistory: []
            }
          ]
        },
        {
          id: '3',
          title: 'Leer 30 minutos',
          description: 'Lectura diaria para crecimiento personal',
          category: 'Desarrollo',
          color: '#8b5cf6',
          icon: '📚',
          progress: 0,
          target: 1,
          unit: 'sesión',
          enabled: true,
          createdAt: new Date().toISOString(),
          reminders: [
            {
              id: 'r6',
              time: '21:00',
              message: 'Hora de leer antes de dormir',
              recurrence: 'daily',
              enabled: true,
              notificationHistory: []
            }
          ]
        },
        {
          id: '4',
          title: 'Meditar',
          description: 'Práctica de mindfulness',
          category: 'Bienestar',
          color: '#ec4899',
          icon: '🧘',
          progress: 0,
          target: 1,
          unit: 'sesión',
          enabled: true,
          createdAt: new Date().toISOString(),
          reminders: [
            {
              id: 'r7',
              time: '08:00',
              message: 'Comienza el día con meditación',
              recurrence: 'daily',
              enabled: true,
              notificationHistory: []
            }
          ]
        }
      ];
      setGoals(exampleGoals);
    }

    // Verificar permisos de notificación
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }

    // Registrar Service Worker para PWA
    registerServiceWorker();
  }, []);

  useEffect(() => {
    // Guardar metas en localStorage
    localStorage.setItem('goals-app', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    // Verificar recordatorios cada minuto
    const interval = setInterval(() => {
      checkReminders();
    }, 60000);

    checkReminders();
    return () => clearInterval(interval);
  }, [goals]);

  const checkReminders = async () => {
    const now = new Date();
    const currentDate = now.toISOString().split('T')[0];
    const currentTime = now.toTimeString().slice(0, 5);

    let updated = false;
    const newGoals = goals.map(goal => {
      if (!goal.enabled) return goal;

      const newReminders = goal.reminders.map(reminder => {
        if (!reminder.enabled || reminder.time !== currentTime) return reminder;

        const lastNotified = reminder.lastNotified ? new Date(reminder.lastNotified) : null;
        
        // Si ya notificó en los últimos 59 segundos, no volver a notificar
        if (lastNotified && (now.getTime() - lastNotified.getTime()) < 59000) {
          return reminder;
        }

        // Enviar notificación
        sendReminderNotification(goal, reminder);
        updated = true;

        return {
          ...reminder,
          lastNotified: now.toISOString(),
          notificationHistory: [...reminder.notificationHistory, now.toISOString()]
        };
      });

      return { ...goal, reminders: newReminders };
    });

    if (updated) {
      setGoals(newGoals);
    }
  };

  const sendReminderNotification = async (goal: Goal, reminder: GoalReminder) => {
    if (notificationPermission !== 'granted') {
      console.warn('⚠️ No se puede enviar notificación: permisos no concedidos');
      return;
    }

    try {
      await sendNotification(
        `${goal.icon} ${goal.title}`,
        {
          body: reminder.message,
          icon: '/icon-192.png',
          badge: '/icon-192.png',
          vibrate: [200, 100, 200],
          tag: `reminder-${goal.id}-${reminder.id}`,
          data: {
            goalId: goal.id,
            reminderId: reminder.id
          }
        }
      );
      console.log(`✅ Recordatorio enviado para: ${goal.title}`);
    } catch (error) {
      console.error('❌ Error al enviar recordatorio:', error);
    }
  };

  const requestNotificationPermission = async () => {
    console.log('🔔 Intentando solicitar permisos de notificación...');
    
    if (!('Notification' in window)) {
      console.error('❌ Este navegador no soporta notificaciones');
      alert('❌ Tu navegador no soporta notificaciones. Usa Chrome, Firefox, Edge o Safari.');
      return;
    }

    console.log('✅ Notification API disponible');
    console.log('Estado actual:', Notification.permission);

    // Si ya está bloqueado, dar instrucciones
    if (Notification.permission === 'denied') {
      console.error('❌ Las notificaciones ya están bloqueadas');
      alert('⚠️ Las notificaciones están bloqueadas. Debes habilitarlas manualmente:\n\n1. Haz clic en el candado 🔒 en la barra de direcciones\n2. Busca "Notificaciones"\n3. Cambia a "Permitir"\n4. Recarga la página');
      return;
    }

    // Si ya están permitidas, enviar prueba
    if (Notification.permission === 'granted') {
      console.log('✅ Ya tienes permisos concedidos');
      sendTestNotification();
      return;
    }

    try {
      console.log('📤 Solicitando permiso...');
      
      const permission = await Notification.requestPermission();
      console.log('📥 Permiso recibido:', permission);
      setNotificationPermission(permission);
      
      if (permission === 'granted') {
        console.log('✅ Permiso concedido, enviando notificación de bienvenida...');
        
        // USAR SERVICE WORKER para la notificación de bienvenida
        try {
          await sendNotification('🎉 ¡Notificaciones Activadas!', {
            body: 'Ahora recibirás recordatorios de tus metas',
            icon: '/icon-192.png',
            badge: '/icon-192.png',
            vibrate: [200, 100, 200],
            tag: 'welcome'
          });
          console.log('✅ Notificación de bienvenida enviada');
        } catch (welcomeError) {
          console.error('❌ Error al enviar notificación de bienvenida:', welcomeError);
        }
        
      } else if (permission === 'denied') {
        console.error('❌ Permiso denegado por el usuario');
        alert('❌ Has rechazado las notificaciones. Si quieres activarlas después:\n\n1. Haz clic en el candado 🔒 en la barra de direcciones\n2. Busca "Notificaciones"\n3. Cambia a "Permitir"\n4. Recarga la página');
      } else {
        console.warn('⚠️ Permiso cerrado sin respuesta (default)');
      }
      
    } catch (error: any) {
      console.error('❌ Error completo:', error);
      alert(`❌ Error: ${error.message || 'No se pudieron activar las notificaciones'}`);
    }
  };

  const sendTestNotification = async () => {
    console.log('🧪 === BOTÓN ENVIAR PRUEBA PRESIONADO ===');
    console.log('Estado de permisos:', notificationPermission);
    console.log('📱 Es móvil:', isMobile());
    console.log('🏠 Es PWA:', isInstalledPWA());
    
    if (notificationPermission !== 'granted') {
      console.error('❌ Permisos no concedidos');
      alert('⚠️ Por favor, activa las notificaciones primero usando el botón "Activar Ahora".');
      return;
    }

    try {
      console.log('🚀 Llamando a sendNotification...');
      await sendNotification('🧪 Notificación de Prueba', {
        body: 'Las notificaciones están funcionando correctamente ✅',
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        vibrate: [200, 100, 200],
        tag: 'test-' + Date.now()
      });
      console.log('✅ ¡Notificación enviada exitosamente!');
      alert('✅ ¡Notificación enviada! Si no la ves, revisa el centro de notificaciones de tu dispositivo.');
      
    } catch (error: any) {
      console.error('❌ Error al enviar notificación de prueba:', error);
      console.error('❌ Detalles del error:', error.message, error.stack);
      alert(`❌ Error: ${error.message || 'No se pudo enviar la notificación'}\n\nRevisa la consola de debugging para más detalles.`);
    }
  };

  const addGoal = (goal: Omit<Goal, 'id' | 'createdAt'>) => {
    const newGoal: Goal = {
      ...goal,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setGoals([...goals, newGoal]);
  };

  const updateGoal = (id: string, updates: Partial<Goal>) => {
    setGoals(goals.map(g => g.id === id ? { ...g, ...updates } : g));
  };

  const deleteGoal = (id: string) => {
    setGoals(goals.filter(g => g.id !== id));
  };

  const updateProgress = (goalId: string, newProgress: number) => {
    setGoals(goals.map(g => 
      g.id === goalId ? { ...g, progress: Math.max(0, Math.min(g.target, newProgress)) } : g
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Notification Permission Banner */}
      {notificationPermission !== 'granted' && (
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-3 shadow-lg">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5" />
              <p className="text-sm font-medium">
                Activa las notificaciones para recibir recordatorios de tus metas
              </p>
            </div>
            <button
              onClick={requestNotificationPermission}
              className="bg-white text-purple-600 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-purple-50 transition-colors flex-shrink-0"
            >
              Activar
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-6 pb-24">
        {activeTab === 'widget' && (
          <WidgetView 
            goals={goals} 
            onUpdateProgress={updateProgress}
            onUpdateGoal={updateGoal}
          />
        )}
        
        {activeTab === 'goals' && (
          <GoalsManager
            goals={goals}
            onAddGoal={addGoal}
            onUpdateGoal={updateGoal}
            onDeleteGoal={deleteGoal}
          />
        )}

        {activeTab === 'dashboard' && (
          <Dashboard goals={goals} />
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-white mb-2">Configuración</h1>
              <p className="text-purple-300">Notificaciones y preferencias de la app</p>
            </div>

            {/* Notification Status Card */}
            <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-white flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Estado de Notificaciones
                </h3>
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                  notificationPermission === 'granted' 
                    ? 'bg-green-500/20 text-green-300' 
                    : 'bg-yellow-500/20 text-yellow-300'
                }`}>
                  {notificationPermission === 'granted' ? '✅ Activadas' : '⏳ Inactivas'}
                </div>
              </div>

              <p className="text-sm text-purple-200 mb-4">
                {notificationPermission === 'granted' 
                  ? 'Las notificaciones están activas. Recibirás recordatorios de tus metas.'
                  : 'Activa las notificaciones para recibir recordatorios en tu dispositivo.'}
              </p>

              <div className="space-y-3">
                {notificationPermission !== 'granted' && (
                  <button
                    onClick={requestNotificationPermission}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-xl transition-all"
                  >
                    🔔 Activar Notificaciones
                  </button>
                )}

                {notificationPermission === 'granted' && (
                  <button
                    onClick={sendTestNotification}
                    className="w-full bg-white/10 text-white px-6 py-3 rounded-xl font-medium hover:bg-white/20 transition-all border border-white/20"
                  >
                    🧪 Enviar Notificación de Prueba
                  </button>
                )}
              </div>
            </div>

            {/* Install Instructions */}
            <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-white mb-4">📱 Instalar como App</h3>
              <p className="text-sm text-purple-200 mb-4">
                Para recibir notificaciones push en tu celular, instala esta app en tu pantalla de inicio.
              </p>
              <div className="space-y-3">
                <div className="bg-white/5 rounded-xl p-4">
                  <div className="font-medium text-white mb-2 flex items-center gap-2">
                    🍎 iPhone (Safari)
                  </div>
                  <ol className="text-sm text-purple-300 space-y-1 list-decimal list-inside">
                    <li>Toca el botón "Compartir" (📤)</li>
                    <li>Selecciona "Agregar a pantalla de inicio"</li>
                    <li>Toca "Agregar"</li>
                    <li>Abre la app desde tu pantalla de inicio</li>
                  </ol>
                </div>

                <div className="bg-white/5 rounded-xl p-4">
                  <div className="font-medium text-white mb-2 flex items-center gap-2">
                    🤖 Android (Chrome)
                  </div>
                  <ol className="text-sm text-purple-300 space-y-1 list-decimal list-inside">
                    <li>Toca el menú (tres puntos ⋮)</li>
                    <li>Selecciona "Instalar app" o "Agregar a pantalla de inicio"</li>
                    <li>Confirma la instalación</li>
                    <li>Abre la app desde tu pantalla de inicio</li>
                  </ol>
                </div>
              </div>

              <div className="mt-4 p-3 bg-blue-500/10 rounded-xl border border-blue-500/20">
                <p className="text-sm text-blue-200">
                  💡 <strong>Importante:</strong> Las notificaciones push solo funcionan cuando la app está instalada como PWA y el sitio usa HTTPS.
                </p>
              </div>
            </div>

            {/* Data Management */}
            <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-white mb-4">💾 Gestión de Datos</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <span className="text-purple-300 text-sm">Total de metas</span>
                  <span className="font-bold text-white">{goals.length}</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <span className="text-purple-300 text-sm">Metas activas</span>
                  <span className="font-bold text-white">{goals.filter(g => g.enabled).length}</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <span className="text-purple-300 text-sm">Total recordatorios</span>
                  <span className="font-bold text-white">
                    {goals.reduce((sum, g) => sum + g.reminders.length, 0)}
                  </span>
                </div>

                <button
                  onClick={() => {
                    if (confirm('¿Eliminar todas las metas y empezar de nuevo? Esta acción no se puede deshacer.')) {
                      setGoals([]);
                      alert('Todas las metas han sido eliminadas.');
                    }
                  }}
                  className="w-full bg-red-500/20 text-red-200 px-4 py-3 rounded-xl text-sm font-medium hover:bg-red-500/30 transition-colors border border-red-500/30"
                >
                  🗑️ Resetear Todos los Datos
                </button>
              </div>
            </div>

            {/* Info sobre el dominio */}
            <div className="bg-gradient-to-r from-orange-500/10 to-red-500/10 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border border-orange-500/20">
              <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
                ⚠️ Requisitos para Notificaciones Push
              </h3>
              <div className="space-y-2 text-sm text-orange-200">
                <p>✅ La app debe estar en un dominio con <strong>HTTPS</strong> (SSL)</p>
                <p>✅ El Service Worker debe estar registrado</p>
                <p>✅ La app debe estar instalada como PWA en el dispositivo</p>
                <p>✅ El usuario debe dar permisos de notificación</p>
              </div>
              <div className="mt-4 p-3 bg-black/20 rounded-xl">
                <p className="text-xs text-orange-300">
                  📝 <strong>Nota:</strong> Si estás viendo esto en Figma Make, las notificaciones pueden no funcionar hasta que subas la app a tu propio dominio con HTTPS.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-slate-900/80 backdrop-blur-xl border-t border-white/10 shadow-2xl">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-around py-3">
            <button
              onClick={() => setActiveTab('widget')}
              className={`flex flex-col items-center gap-1 px-6 py-2 rounded-xl transition-all ${
                activeTab === 'widget'
                  ? 'text-purple-400 bg-purple-500/20 scale-105'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Home className="w-6 h-6" />
              <span className="text-xs font-medium">Widget</span>
            </button>

            <button
              onClick={() => setActiveTab('goals')}
              className={`flex flex-col items-center gap-1 px-6 py-2 rounded-xl transition-all ${
                activeTab === 'goals'
                  ? 'text-purple-400 bg-purple-500/20 scale-105'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Target className="w-6 h-6" />
              <span className="text-xs font-medium">Metas</span>
            </button>

            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex flex-col items-center gap-1 px-6 py-2 rounded-xl transition-all ${
                activeTab === 'dashboard'
                  ? 'text-purple-400 bg-purple-500/20 scale-105'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-6 h-6" />
              <span className="text-xs font-medium">Stats</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex flex-col items-center gap-1 px-6 py-2 rounded-xl transition-all ${
                activeTab === 'settings'
                  ? 'text-purple-400 bg-purple-500/20 scale-105'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Settings className="w-6 h-6" />
              <span className="text-xs font-medium">Ajustes</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}