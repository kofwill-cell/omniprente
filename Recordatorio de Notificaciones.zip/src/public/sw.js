// Service Worker para notificaciones PWA
const CACHE_NAME = 'goals-app-v2';

console.log('🚀 Service Worker cargado');

// Instalación del Service Worker
self.addEventListener('install', (event) => {
  console.log('✅ [SW] Instalando Service Worker...');
  self.skipWaiting();
});

// Activación
self.addEventListener('activate', (event) => {
  console.log('✅ [SW] Service Worker activado');
  event.waitUntil(self.clients.claim());
});

// Escuchar mensajes para mostrar notificaciones
self.addEventListener('message', (event) => {
  console.log('📩 [SW] Mensaje recibido:', event.data);
  
  if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
    const { title, options } = event.data;
    
    console.log('🔔 [SW] Intentando mostrar notificación:', title);
    
    self.registration.showNotification(title, {
      body: options.body || 'Notificación',
      icon: options.icon || '/icon-192.png',
      badge: options.badge || '/icon-192.png',
      vibrate: options.vibrate || [200, 100, 200],
      requireInteraction: false,
      silent: false,
      tag: options.tag || 'default',
      data: options.data || {}
    }).then(() => {
      console.log('✅ [SW] Notificación mostrada exitosamente');
    }).catch((error) => {
      console.error('❌ [SW] Error al mostrar notificación:', error);
    });
  }
});

// Click en notificación
self.addEventListener('notificationclick', (event) => {
  console.log('👆 [SW] Click en notificación');
  event.notification.close();
  
  event.waitUntil(
    clients.openWindow('/').then(() => {
      console.log('✅ [SW] App abierta desde notificación');
    })
  );
});

// Close de notificación
self.addEventListener('notificationclose', (event) => {
  console.log('🔕 [SW] Notificación cerrada');
});

// Fetch - responder desde cache o red
self.addEventListener('fetch', (event) => {
  // Solo cachear peticiones GET
  if (event.request.method !== 'GET') return;
  
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        return response || fetch(event.request);
      })
  );
});

console.log('✅ [SW] Todos los event listeners registrados');
