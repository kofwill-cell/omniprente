# 🚀 GUÍA COMPLETA: Deploy a Producción con Notificaciones Push

## ✅ Lo que tienes ahora:

✔️ PWA completa con Service Worker
✔️ Sistema de notificaciones push configurado
✔️ Interfaz móvil optimizada
✔️ Gestión de metas y recordatorios
✔️ Código listo para producción

---

## 📋 REQUISITOS para que funcionen las notificaciones PUSH:

1. ✅ **Dominio con HTTPS** (SSL/TLS) - OBLIGATORIO
2. ✅ **Service Worker registrado** - Ya está implementado
3. ✅ **App instalada como PWA** - El usuario debe instalarla
4. ✅ **Permisos de notificación** - El usuario debe aceptarlos

---

## 🌐 OPCIÓN 1: Deploy en Vercel (RECOMENDADO - GRATIS)

### Paso 1: Preparar el Proyecto Localmente

```bash
# Crear proyecto con Vite
npm create vite@latest mi-app-metas -- --template react-ts
cd mi-app-metas

# Instalar dependencias
npm install lucide-react recharts motion
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### Paso 2: Copiar Archivos

Copia estos archivos desde Figma Make a tu proyecto local:

**Estructura:**
```
mi-app-metas/
├── public/
│   ├── manifest.json
│   ├── sw.js
│   ├── icon-192.png
│   └── icon-512.png
├── src/
│   ├── components/
│   │   ├── WidgetView.tsx
│   │   ├── GoalsManager.tsx
│   │   ├── GoalCard.tsx
│   │   ├── GoalForm.tsx
│   │   ├── Dashboard.tsx
│   │   ├── ReminderForm.tsx
│   │   └── ReminderCard.tsx
│   ├── utils/
│   │   └── notifications.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── package.json
├── vite.config.ts
└── tailwind.config.js
```

### Paso 3: Configurar Tailwind CSS

**`tailwind.config.js`:**
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

**`src/index.css`:**
Copia el contenido de `/styles/globals.css`

### Paso 4: Actualizar `vite.config.ts`

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
})
```

### Paso 5: Deploy en Vercel

```bash
# Instalar Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

**O usa la interfaz web:**
1. Ve a [vercel.com](https://vercel.com)
2. Conecta tu repositorio de GitHub
3. Deploy automático

### ✅ Vercel incluye HTTPS gratis automáticamente

---

## 🌐 OPCIÓN 2: Deploy en Netlify (GRATIS)

### Método A: Drag & Drop

1. Construye el proyecto:
```bash
npm run build
```

2. Ve a [netlify.com](https://netlify.com)

3. Arrastra la carpeta `dist/` al navegador

4. ✅ Tu app tendrá HTTPS automáticamente

### Método B: Git Deploy

1. Sube tu código a GitHub

2. En Netlify:
   - New site from Git
   - Selecciona tu repositorio
   - Build command: `npm run build`
   - Publish directory: `dist`

3. Deploy automático con HTTPS

---

## 🌐 OPCIÓN 3: GitHub Pages (GRATIS)

### Paso 1: Configurar `vite.config.ts`

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/nombre-de-tu-repo/',  // ⚠️ Importante
  build: {
    outDir: 'dist',
  },
})
```

### Paso 2: Crear `deploy.sh`

```bash
#!/usr/bin/env sh

set -e

npm run build

cd dist

git init
git add -A
git commit -m 'deploy'
git push -f git@github.com:tu-usuario/tu-repo.git master:gh-pages

cd -
```

### Paso 3: Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

### ⚠️ LIMITACIÓN: GitHub Pages NO tiene HTTPS en dominios personalizados gratis

**Usa Vercel o Netlify en su lugar**

---

## 🌐 OPCIÓN 4: Tu Propio Dominio + Hosting

### Hosting recomendados con HTTPS gratis:

1. **Digital Ocean App Platform** - $5/mes
2. **Heroku** - Gratis (con limitaciones)
3. **Railway.app** - Gratis hasta cierto uso
4. **Render.com** - Gratis para sitios estáticos

### Pasos generales:

1. Construye el proyecto:
```bash
npm run build
```

2. Sube la carpeta `dist/` a tu hosting

3. Configura el certificado SSL (Let's Encrypt es gratis)

4. Apunta tu dominio al hosting

---

## 📱 CÓMO PROBAR LAS NOTIFICACIONES DESPUÉS DEL DEPLOY

### En Android (Chrome):

1. Abre tu app en Chrome: `https://tu-dominio.com`

2. **Instalar la PWA:**
   - Menú (⋮) → "Instalar app" o "Agregar a pantalla de inicio"
   - Acepta la instalación

3. **Activar notificaciones:**
   - Abre la app DESDE la pantalla de inicio (icono)
   - Ve a Ajustes → Activar Notificaciones
   - Acepta el permiso

4. **Probar:**
   - Presiona "Enviar Notificación de Prueba"
   - Deberías ver una notificación en tu barra de notificaciones

5. **Configurar recordatorios:**
   - Crea metas con horarios específicos
   - Cuando llegue la hora, recibirás la notificación

### En iPhone (Safari):

1. Abre tu app en Safari: `https://tu-dominio.com`

2. **Instalar la PWA:**
   - Botón "Compartir" (📤)
   - "Agregar a pantalla de inicio"
   - "Agregar"

3. **Activar notificaciones:**
   - Abre la app desde tu pantalla de inicio
   - Ve a Ajustes → Activar Notificaciones
   - Acepta el permiso

4. **Probar:**
   - Igual que en Android

⚠️ **NOTA iOS:** Las notificaciones en iOS Safari tienen limitaciones. Funciona mejor en iOS 16.4+

---

## 🔧 ARCHIVOS CRÍTICOS PARA PWA

### `/public/manifest.json` (Ya lo tienes)

```json
{
  "name": "Metas y Recordatorios",
  "short_name": "Metas",
  "description": "App de metas con recordatorios y notificaciones push",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0f172a",
  "theme_color": "#8b5cf6",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}
```

### `/public/sw.js` (Ya lo tienes)

Este Service Worker ya está configurado correctamente.

### `/utils/notifications.ts` (Ya lo tienes)

El sistema de notificaciones ya detecta automáticamente:
- Si hay Service Worker disponible
- Si la app está instalada
- Si es móvil o desktop

---

## ✅ CHECKLIST ANTES DE DEPLOY:

- [ ] Todas las dependencias instaladas
- [ ] Build funciona sin errores (`npm run build`)
- [ ] Service Worker en `/public/sw.js`
- [ ] Manifest en `/public/manifest.json`
- [ ] Íconos en `/public/icon-192.png` y `/public/icon-512.png`
- [ ] El dominio tendrá HTTPS
- [ ] Has probado la build localmente (`npm run preview`)

---

## 🔍 DEBUGGING EN PRODUCCIÓN:

### Chrome DevTools:

1. F12 → Application tab
2. Revisa:
   - **Manifest**: Debe mostrar tu manifest.json
   - **Service Workers**: Debe estar "activated and running"
   - **Storage**: LocalStorage debe tener tus metas

### Verificar Notificaciones:

1. Chrome → Configuración → Privacidad y seguridad → Configuración de sitios
2. Notificaciones → Busca tu dominio
3. Debe estar en "Permitir"

---

## 📊 MONITOREO:

Una vez en producción, puedes:

- Ver cuántas personas instalan la PWA (Google Analytics)
- Monitorear errores con Sentry
- Ver uso de notificaciones en Chrome DevTools

---

## 🆘 PROBLEMAS COMUNES:

### "Service Worker no se registra"
✅ **Solución:** Asegúrate de estar en HTTPS

### "Las notificaciones no llegan"
✅ **Solución:** 
1. App instalada como PWA
2. Permisos concedidos
3. App abierta al menos una vez

### "No puedo instalar la PWA"
✅ **Solución:**
1. Verifica que manifest.json sea válido
2. Debe haber HTTPS
3. Service Worker debe estar activo

---

## 📦 PACKAGE.JSON COMPLETO:

```json
{
  "name": "app-metas-recordatorios",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "lucide-react": "^0.400.0",
    "recharts": "^2.12.0",
    "motion": "^10.18.0"
  },
  "devDependencies": {
    "@types/react": "^18.3.3",
    "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.3.1",
    "typescript": "^5.5.3",
    "vite": "^5.3.4",
    "tailwindcss": "^3.4.1",
    "postcss": "^8.4.38",
    "autoprefixer": "^10.4.19"
  }
}
```

---

## 🎉 ¡LISTO PARA PRODUCCIÓN!

Tu app está 100% lista para funcionar en un dominio con HTTPS.

**Recomendación:** Usa **Vercel** o **Netlify** para un deploy rápido y gratuito con HTTPS automático.

**¿Necesitas ayuda?** Revisa los logs en la consola del navegador (F12).
