# 📱 CÓMO PROBAR LA APP DE METAS Y NOTIFICACIONES

## ✅ PASO 1: Activar Notificaciones en la Computadora

### Opción A: Usar el Banner Superior
1. Cuando abras la app, verás un **banner morado** en la parte superior
2. Haz clic en el botón **"Activar"**
3. Te aparecerá una ventana emergente del navegador
4. Selecciona **"Permitir"** o **"Allow"**

### Opción B: Usar la Sección Ajustes
1. Haz clic en el ícono de **"Ajustes"** (⚙️) en el menú inferior
2. En la sección "Notificaciones", haz clic en **"Activar Notificaciones"**
3. Selecciona **"Permitir"** cuando aparezca el popup

### ✅ Verificar que Funcionó
- Deberías ver una notificación que dice: **"🎉 ¡Notificaciones Activadas!"**
- En Ajustes, el estado cambiará a: **"✅ Activadas"**
- Aparecerá un nuevo botón: **"Enviar Notificación de Prueba"**

---

## 🧪 PASO 2: Probar las Notificaciones

### Prueba Rápida (Recomendado)
1. Ve a **"Ajustes"** (ícono ⚙️)
2. Haz clic en **"Enviar Notificación de Prueba"**
3. Deberías ver una notificación que dice: **"🧪 Notificación de Prueba"**

### Prueba con Meta Real
1. Ve a **"Metas"** (ícono 🎯)
2. Haz clic en **"Crear Nueva Meta"**
3. Llena el formulario:
   - **Nombre:** "Prueba de Notificación"
   - **Categoría:** Cualquiera
   - **Meta diaria:** 1
   - **Unidad:** vez
4. En la sección **"Recordatorios"**:
   - Pon una hora **2 minutos después** de la hora actual
   - Ejemplo: Si son las 3:15 PM, pon 15:17
5. Haz clic en **"Crear Meta"**
6. Espera 2 minutos
7. ¡Deberías recibir la notificación!

---

## 📲 PASO 3: Probar en el Celular

### Si tienes el link de Figma Make:

#### Para iPhone/Safari:
1. **Abre Safari** (no Chrome)
2. Pega el link de Figma Make
3. Cuando cargue la app, toca el ícono de **"Compartir"** (📤)
4. Desplázate hacia abajo y selecciona **"Agregar a pantalla de inicio"**
5. Toca **"Agregar"**
6. La app aparecerá en tu pantalla como una app normal
7. Ábrela y sigue los pasos 1 y 2 de arriba

#### Para Android/Chrome:
1. **Abre Chrome**
2. Pega el link de Figma Make
3. Toca el menú (tres puntos **⋮**)
4. Selecciona **"Instalar app"** o **"Agregar a pantalla de inicio"**
5. Confirma la instalación
6. Ábrela y sigue los pasos 1 y 2 de arriba

---

## 🚨 SOLUCIÓN DE PROBLEMAS

### ❌ El botón de "Activar" no hace nada

**Posibles causas:**
1. **El navegador bloqueó las notificaciones**
   - **Solución:** Ve a la configuración del navegador
   - Chrome: `chrome://settings/content/notifications`
   - Busca la URL de tu app y cambia a "Permitir"

2. **Usas un navegador que no soporta notificaciones**
   - **Solución:** Usa Chrome, Firefox, Edge o Safari

3. **Las notificaciones están bloqueadas a nivel del sistema**
   - **Windows:** Configuración → Sistema → Notificaciones
   - **Mac:** Preferencias del Sistema → Notificaciones
   - **iOS:** Ajustes → Safari → Notificaciones
   - **Android:** Ajustes → Apps → Chrome → Notificaciones

### ❌ No aparece el popup de permisos

**Solución:**
1. Busca un ícono de **🔒** o **🔔** en la barra de direcciones
2. Haz clic y selecciona "Permitir notificaciones"
3. Recarga la página

### ❌ La app no carga en el celular

**Problema común:** El link de Figma Make pide login

**Soluciones:**
1. **Abre el link en modo incógnito**
2. **Inicia sesión con la misma cuenta de Google que usas en la computadora**
3. **Pide un link público:** En Figma Make, busca la opción "Share" → "Public link"

### ❌ Las notificaciones no llegan a la hora programada

**Verifica:**
1. ✅ La app está **abierta** (puede estar en segundo plano)
2. ✅ La meta está **activada** (con el toggle verde)
3. ✅ El recordatorio está **habilitado**
4. ✅ La hora está en formato 24h: `14:30` no `2:30 PM`

---

## 💡 CONSEJOS PRO

### Para que funcione como Widget Real:

1. **Instala la PWA** (no solo agregues un marcador)
2. **Deja la app abierta en segundo plano**
3. **No cierres todas las pestañas** del navegador
4. **En iOS:** Safari debe estar ejecutándose en segundo plano

### Crear una Meta de Prueba Perfecta:

```
Nombre: Tomar agua
Categoría: Salud
Ícono: 💧
Meta: 8
Unidad: vasos

Recordatorios:
- 09:00 - "Primer vaso del día"
- 12:00 - "Hora de hidratarte"
- 15:00 - "Tarde de agua"
- 18:00 - "Casi terminamos el día"
```

---

## 🎯 CHECKLIST FINAL

Marca cada paso cuando lo completes:

- [ ] Abro la app en el navegador
- [ ] Veo el banner morado de notificaciones
- [ ] Hago clic en "Activar"
- [ ] Acepto los permisos en el popup
- [ ] Recibo la notificación de confirmación
- [ ] Voy a Ajustes y hago clic en "Enviar Notificación de Prueba"
- [ ] Veo la notificación de prueba
- [ ] Creo una meta con un recordatorio en 2 minutos
- [ ] Espero 2 minutos y recibo la notificación
- [ ] ✅ ¡TODO FUNCIONA!

---

## 📞 ¿SIGUE SIN FUNCIONAR?

Dime **exactamente** en qué paso estás atascado:

1. ¿En qué navegador estás? (Chrome, Safari, Firefox, etc.)
2. ¿En qué dispositivo? (Windows, Mac, iPhone, Android)
3. ¿Qué pasa cuando haces clic en "Activar"?
4. ¿Aparece algún error en la consola? (Presiona F12 → pestaña Console)

¡Con esa info puedo ayudarte mejor! 🚀
