// Callback global para notificaciones in-app (fallback)
let inAppNotificationCallback: ((title: string, body: string, icon?: string) => void) | null = null;

export const setInAppNotificationCallback = (callback: (title: string, body: string, icon?: string) => void) => {
  inAppNotificationCallback = callback;
  console.log('✅ Callback de notificaciones in-app registrado');
};

// Detectar si estamos en dispositivo móvil
export const isMobile = (): boolean => {
  if (typeof window === 'undefined') return false;
  
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    navigator.userAgent
  );
};

// Detectar si estamos en iOS
export const isIOS = (): boolean => {
  if (typeof window === 'undefined') return false;
  
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
};

// Detectar si la app está instalada como PWA
export const isInstalledPWA = (): boolean => {
  if (typeof window === 'undefined') return false;
  
  // Verificar si está en standalone mode
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
  const isIosStandalone = (window.navigator as any).standalone === true;
  const isAndroidApp = document.referrer.includes('android-app://');
  
  console.log('🔍 Verificando si es PWA instalada:');
  console.log('  - display-mode: standalone =', isStandalone);
  console.log('  - iOS standalone =', isIosStandalone);
  console.log('  - Android app =', isAndroidApp);
  console.log('  - Resultado final =', isStandalone || isIosStandalone || isAndroidApp);
  
  return isStandalone || isIosStandalone || isAndroidApp;
};

// Enviar notificación usando Service Worker (para móvil)
export const sendNotificationViaSW = async (
  title: string,
  options: NotificationOptions
): Promise<void> => {
  console.log('📱 Intentando enviar notificación via Service Worker...');
  
  if (!('serviceWorker' in navigator)) {
    throw new Error('Service Worker no disponible en este navegador');
  }

  try {
    // Esperar a que el SW esté listo
    const registration = await navigator.serviceWorker.ready;
    console.log('✅ Service Worker listo');
    
    // Usar el método showNotification del registration
    await registration.showNotification(title, {
      ...options,
      icon: options.icon || '/icon-192.png',
      badge: options.badge || '/icon-192.png',
      vibrate: options.vibrate || [200, 100, 200]
    });
    
    console.log('✅ Notificación enviada via Service Worker');
  } catch (error) {
    console.error('❌ Error en Service Worker:', error);
    throw error;
  }
};

// Enviar notificación directa (para desktop)
export const sendNotificationDirect = (
  title: string,
  options: NotificationOptions
): Notification => {
  console.log('💻 Enviando notificación directa (desktop)...');
  const notification = new Notification(title, options);
  console.log('✅ Notificación directa creada');
  return notification;
};

// Función universal para enviar notificaciones
export const sendNotification = async (
  title: string,
  options: NotificationOptions
): Promise<void> => {
  console.log('🔔 === ENVIANDO NOTIFICACIÓN ===');
  console.log('📝 Título:', title);
  console.log('📱 Es móvil:', isMobile());
  console.log('📲 Es iOS:', isIOS());
  console.log('🏠 Es PWA instalada:', isInstalledPWA());
  console.log('✅ Service Worker disponible:', 'serviceWorker' in navigator);
  
  // Verificar permisos primero
  if (Notification.permission !== 'granted') {
    console.warn('⚠️ Permisos no concedidos, usando notificación in-app como fallback');
    if (inAppNotificationCallback) {
      inAppNotificationCallback(title, options.body || '', options.icon);
      return;
    }
    throw new Error('No tienes permisos de notificación. Actívalos primero.');
  }
  
  // Intentar con Service Worker primero
  if ('serviceWorker' in navigator) {
    try {
      console.log('🔄 Intentando con Service Worker...');
      await sendNotificationViaSW(title, options);
      console.log('✅ Notificación enviada correctamente via Service Worker');
      return;
    } catch (swError) {
      console.warn('⚠️ Service Worker falló, intentando método alternativo...', swError);
    }
  }
  
  // Fallback: Intentar notificación directa
  try {
    console.log('🔄 Intentando notificación directa...');
    sendNotificationDirect(title, options);
    console.log('✅ Notificación enviada correctamente via método directo');
    return;
  } catch (directError) {
    console.warn('⚠️ Notificación directa también falló, usando in-app...', directError);
  }
  
  // Último fallback: Notificación in-app
  if (inAppNotificationCallback) {
    console.log('📱 Usando notificación in-app como último recurso');
    inAppNotificationCallback(title, options.body || '', options.icon);
  } else {
    console.error('❌ Todos los métodos fallaron y no hay callback in-app configurado');
    throw new Error('No se pudo enviar la notificación por ningún método disponible.');
  }
};

// Registrar Service Worker
export const registerServiceWorker = async (): Promise<ServiceWorkerRegistration | null> => {
  if (!('serviceWorker' in navigator)) {
    console.warn('⚠️ Service Worker no disponible en este navegador');
    return null;
  }

  try {
    console.log('🔄 Registrando Service Worker inline...');
    
    // Crear el Service Worker como un blob inline (no requiere archivo externo)
    const swCode = `
      console.log('✅ [SW] Service Worker inline iniciado');
      
      self.addEventListener('install', (event) => {
        console.log('✅ [SW] Instalando...');
        self.skipWaiting();
      });
      
      self.addEventListener('activate', (event) => {
        console.log('✅ [SW] Activando...');
        event.waitUntil(self.clients.claim());
      });
      
      self.addEventListener('notificationclick', (event) => {
        console.log('👆 [SW] Click en notificación');
        event.notification.close();
        event.waitUntil(clients.openWindow('/'));
      });
      
      self.addEventListener('notificationclose', (event) => {
        console.log('🔕 [SW] Notificación cerrada');
      });
    `;
    
    const blob = new Blob([swCode], { type: 'application/javascript' });
    const swUrl = URL.createObjectURL(blob);
    
    const registration = await navigator.serviceWorker.register(swUrl, {
      scope: '/'
    });
    
    console.log('✅ Service Worker inline registrado:', registration);
    
    // Esperar a que esté activo
    await navigator.serviceWorker.ready;
    console.log('✅ Service Worker inline listo y activo');
    
    return registration;
  } catch (error) {
    console.error('❌ Error al registrar Service Worker:', error);
    return null;
  }
};