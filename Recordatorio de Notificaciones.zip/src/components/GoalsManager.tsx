import { useState } from 'react';
import { GoalForm } from './GoalForm';
import { GoalCard } from './GoalCard';
import { Plus, Search, Filter } from 'lucide-react';
import type { Goal } from '../App';

interface GoalsManagerProps {
  goals: Goal[];
  onAddGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  onUpdateGoal: (id: string, updates: Partial<Goal>) => void;
  onDeleteGoal: (id: string) => void;
}

export function GoalsManager({ 
  goals, 
  onAddGoal, 
  onUpdateGoal,
  onDeleteGoal 
}: GoalsManagerProps) {
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const handleAddGoal = (goal: Omit<Goal, 'id' | 'createdAt'>) => {
    onAddGoal(goal);
    setShowForm(false);
  };

  // Filtrar metas
  const filteredGoals = goals.filter(goal => {
    const matchesSearch = goal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         goal.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || goal.category === filterCategory;
    
    return matchesSearch && matchesCategory;
  });

  // Obtener categorías únicas
  const categories = Array.from(new Set(goals.map(g => g.category)));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-2">Mis Metas</h1>
        <p className="text-purple-300">Crea y gestiona tus objetivos diarios</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-lg p-4 border border-white/20">
        <div className="grid md:grid-cols-2 gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-purple-300" />
            <input
              type="text"
              placeholder="Buscar metas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
            />
          </div>

          {/* Filter by Category */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-purple-300" />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none appearance-none"
            >
              <option value="all" className="bg-slate-800">Todas las categorías</option>
              {categories.map(cat => (
                <option key={cat} value={cat} className="bg-slate-800">{cat}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Add Button */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-5 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-3 shadow-xl hover:shadow-2xl hover:scale-[1.02]"
      >
        <Plus className="w-7 h-7" />
        Crear Nueva Meta
      </button>

      {/* Form Modal */}
      {showForm && (
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Nueva Meta</h2>
            <button
              onClick={() => setShowForm(false)}
              className="text-white/60 hover:text-white text-3xl font-light w-10 h-10 flex items-center justify-center hover:bg-white/10 rounded-full transition-all"
            >
              ×
            </button>
          </div>
          <GoalForm onAddGoal={handleAddGoal} />
        </div>
      )}

      {/* Goals List */}
      <div className="space-y-4">
        {filteredGoals.length > 0 ? (
          filteredGoals.map(goal => (
            <GoalCard
              key={goal.id}
              goal={goal}
              onUpdate={onUpdateGoal}
              onDelete={onDeleteGoal}
            />
          ))
        ) : (
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-xl p-12 text-center border border-white/20">
            <div className="text-6xl mb-4">🎯</div>
            <h3 className="text-2xl font-bold text-white mb-2">
              No hay metas
            </h3>
            <p className="text-purple-300">
              {searchQuery || filterCategory !== 'all'
                ? 'No se encontraron resultados con los filtros aplicados'
                : 'Crea tu primera meta para comenzar'}
            </p>
          </div>
        )}
      </div>

      {/* Summary */}
      {filteredGoals.length > 0 && (
        <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur rounded-2xl p-4 text-center border border-white/20">
          <p className="text-white">
            Mostrando <span className="font-bold text-purple-300">{filteredGoals.length}</span> de{' '}
            <span className="font-bold">{goals.length}</span> metas
          </p>
        </div>
      )}
    </div>
  );
}
