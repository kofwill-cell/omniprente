import { AlertCircle, Chrome, Globe } from 'lucide-react';

export function UnblockNotifications() {
  return (
    <div className="bg-red-500/10 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border-2 border-red-500/30">
      <div className="flex items-start gap-4 mb-6">
        <div className="p-3 bg-red-500/20 rounded-xl">
          <AlertCircle className="w-8 h-8 text-red-400" />
        </div>
        <div>
          <h3 className="font-bold text-white text-xl mb-2">
            🔒 Notificaciones Bloqueadas
          </h3>
          <p className="text-red-200 text-sm">
            Las notificaciones están bloqueadas en tu navegador. Sigue estos pasos para habilitarlas:
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Chrome/Edge */}
        <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <Chrome className="w-6 h-6 text-blue-400" />
            <h4 className="font-semibold text-white text-lg">
              Chrome / Edge / Brave
            </h4>
          </div>
          
          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                1
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Busca el <strong className="text-white">candado 🔒</strong> o el <strong className="text-white">ícono de información ⓘ</strong> a la izquierda de la URL en la barra de direcciones
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                2
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Haz clic en él para abrir el menú de permisos del sitio
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                3
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Busca <strong className="text-white">"Notificaciones"</strong> en la lista
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                4
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Cambia el estado de <strong className="text-red-400">"Bloquear"</strong> a <strong className="text-green-400">"Permitir"</strong>
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                5
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  <strong className="text-white">Recarga la página</strong> presionando F5 o Ctrl+R (Cmd+R en Mac)
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/30">
            <p className="text-xs text-blue-300">
              💡 <strong>Tip:</strong> También puedes ir a chrome://settings/content/notifications y buscar este sitio en la lista
            </p>
          </div>
        </div>

        {/* Firefox */}
        <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-6 h-6 text-orange-400" />
            <h4 className="font-semibold text-white text-lg">
              Firefox
            </h4>
          </div>
          
          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                1
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Haz clic en el <strong className="text-white">candado 🔒</strong> o el <strong className="text-white">ícono de información ⓘ</strong> en la barra de direcciones
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                2
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Selecciona <strong className="text-white">"Más información"</strong> o <strong className="text-white">"Connection Secure"</strong>
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                3
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Ve a la pestaña <strong className="text-white">"Permisos"</strong>
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                4
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Encuentra <strong className="text-white">"Enviar notificaciones"</strong> y desmarca <strong className="text-white">"Usar valores predeterminados"</strong>
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                5
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Selecciona <strong className="text-green-400">"Permitir"</strong> y recarga la página
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Safari */}
        <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-6 h-6 text-blue-400" />
            <h4 className="font-semibold text-white text-lg">
              Safari (Mac/iPhone)
            </h4>
          </div>
          
          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                1
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  <strong className="text-white">Mac:</strong> Safari → Preferencias → Sitios web → Notificaciones
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                2
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Busca este sitio web en la lista
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                3
              </div>
              <div className="flex-1">
                <p className="text-purple-200 text-sm">
                  Cambia a <strong className="text-green-400">"Permitir"</strong>
                </p>
              </div>
            </div>

            <div className="mt-4 p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
              <p className="text-xs text-yellow-300">
                ⚠️ <strong>iPhone:</strong> Las notificaciones web en iOS solo funcionan si instalas la app (Compartir → Agregar a pantalla de inicio)
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Final Tips */}
      <div className="mt-6 p-4 bg-purple-500/10 rounded-xl border border-purple-500/30">
        <h5 className="font-semibold text-white mb-2 flex items-center gap-2">
          💡 Consejos Importantes
        </h5>
        <ul className="text-sm text-purple-200 space-y-2">
          <li className="flex gap-2">
            <span className="text-purple-400">•</span>
            <span>Después de cambiar los permisos, <strong className="text-white">siempre recarga la página</strong></span>
          </li>
          <li className="flex gap-2">
            <span className="text-purple-400">•</span>
            <span>Si sigues teniendo problemas, intenta <strong className="text-white">cerrar y abrir el navegador completamente</strong></span>
          </li>
          <li className="flex gap-2">
            <span className="text-purple-400">•</span>
            <span>En móvil, asegúrate de que tu navegador tenga permisos de notificación a nivel del sistema operativo</span>
          </li>
        </ul>
      </div>

      {/* Reload Button */}
      <div className="mt-6">
        <button
          onClick={() => window.location.reload()}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white px-6 py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2 text-lg"
        >
          🔄 Ya Cambié los Permisos - Recargar Página
        </button>
      </div>
    </div>
  );
}
