import { useState } from 'react';
import { 
  Trash2, Clock, Tag, MoreVertical, 
  Bell, BellOff, TrendingUp, Target 
} from 'lucide-react';
import type { Goal } from '../App';

interface GoalCardProps {
  goal: Goal;
  onUpdate: (id: string, updates: Partial<Goal>) => void;
  onDelete: (id: string) => void;
}

export function GoalCard({ goal, onUpdate, onDelete }: GoalCardProps) {
  const [showMenu, setShowMenu] = useState(false);

  const handleToggle = () => {
    onUpdate(goal.id, { enabled: !goal.enabled });
  };

  const handleDelete = () => {
    if (confirm(`¿Estás seguro de que quieres eliminar "${goal.title}"?`)) {
      onDelete(goal.id);
    }
  };

  const progressPercentage = (goal.progress / goal.target) * 100;
  const totalNotifications = goal.reminders.reduce((sum, r) => sum + r.notificationHistory.length, 0);

  return (
    <div 
      className={`bg-white/10 backdrop-blur-xl rounded-3xl shadow-xl overflow-hidden border border-white/20 transition-all hover:scale-[1.01] ${
        !goal.enabled ? 'opacity-60' : ''
      }`}
    >
      <div className="p-6">
        <div className="flex items-start gap-4">
          {/* Icon */}
          <div 
            className="text-5xl w-16 h-16 flex items-center justify-center rounded-2xl flex-shrink-0"
            style={{ backgroundColor: `${goal.color}30` }}
          >
            {goal.icon}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-3">
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-1">
                  {goal.title}
                </h3>
                {goal.description && (
                  <p className="text-sm text-purple-300">
                    {goal.description}
                  </p>
                )}
              </div>
              
              {/* Menu Button */}
              <div className="relative">
                <button
                  onClick={() => setShowMenu(!showMenu)}
                  className="p-2 text-purple-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>

                {showMenu && (
                  <>
                    <div 
                      className="fixed inset-0 z-10"
                      onClick={() => setShowMenu(false)}
                    />
                    <div className="absolute right-0 mt-2 w-48 bg-slate-800 rounded-xl shadow-xl border border-white/20 py-1 z-20">
                      <button
                        onClick={() => {
                          handleToggle();
                          setShowMenu(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-white hover:bg-white/10 flex items-center gap-2"
                      >
                        {goal.enabled ? <BellOff className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
                        {goal.enabled ? 'Desactivar' : 'Activar'}
                      </button>
                      <button
                        onClick={() => {
                          handleDelete();
                          setShowMenu(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-red-400 hover:bg-red-500/10 flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Eliminar
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Meta Information */}
            <div className="flex flex-wrap gap-2 mb-4">
              <div className="flex items-center gap-1.5 text-xs text-purple-300 bg-white/10 px-3 py-1.5 rounded-lg">
                <Tag className="w-3 h-3" />
                <span>{goal.category}</span>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-purple-300 bg-white/10 px-3 py-1.5 rounded-lg">
                <Target className="w-3 h-3" />
                <span>{goal.target} {goal.unit}/día</span>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-purple-300 bg-white/10 px-3 py-1.5 rounded-lg">
                <Clock className="w-3 h-3" />
                <span>{goal.reminders.filter(r => r.enabled).length} recordatorios</span>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-white font-medium">
                  Progreso: {goal.progress} / {goal.target}
                </span>
                <span className="text-purple-300 font-bold">
                  {Math.round(progressPercentage)}%
                </span>
              </div>
              <div className="h-2.5 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(progressPercentage, 100)}%`,
                    backgroundColor: goal.color
                  }}
                />
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center gap-4 pt-3 border-t border-white/10">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-purple-300">
                  <span className="font-semibold text-white">{totalNotifications}</span> notificaciones
                </span>
              </div>

              {/* Status Badge */}
              <span 
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ml-auto ${
                  goal.enabled 
                    ? 'bg-green-500/20 text-green-300' 
                    : 'bg-gray-500/20 text-gray-400'
                }`}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${goal.enabled ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`} />
                {goal.enabled ? 'Activa' : 'Inactiva'}
              </span>
            </div>
          </div>
        </div>

        {/* Reminders Preview */}
        {goal.reminders.length > 0 && (
          <div className="mt-4 pt-4 border-t border-white/10">
            <div className="text-xs text-purple-300 mb-2 font-semibold">Horarios de recordatorio:</div>
            <div className="flex flex-wrap gap-2">
              {goal.reminders
                .filter(r => r.enabled)
                .sort((a, b) => a.time.localeCompare(b.time))
                .map(reminder => (
                  <div 
                    key={reminder.id}
                    className="bg-white/5 px-3 py-1.5 rounded-lg text-xs text-white font-medium"
                  >
                    {reminder.time}
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
