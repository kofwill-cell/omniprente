import { useState } from 'react';
import { Plus, Trash2, Clock, Type, AlignLeft, Tag, Palette, Target, Hash } from 'lucide-react';
import type { Goal, GoalReminder } from '../App';

interface GoalFormProps {
  onAddGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
}

const CATEGORIES = [
  'Salud',
  'Fitness',
  'Trabajo',
  'Estudio',
  'Desarrollo',
  'Bienestar',
  'Finanzas',
  'Familia',
  'Hogar',
  'Otro'
];

const COLORS = [
  '#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', 
  '#ef4444', '#ec4899', '#6366f1', '#14b8a6'
];

const ICONS = [
  '💧', '🏃', '📚', '🧘', '💪', '🎯', '✨', '🌟',
  '⚡', '🔥', '🌱', '🎨', '💼', '🏠', '❤️', '🧠'
];

export function GoalForm({ onAddGoal }: GoalFormProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Salud');
  const [color, setColor] = useState('#8b5cf6');
  const [icon, setIcon] = useState('🎯');
  const [target, setTarget] = useState(1);
  const [unit, setUnit] = useState('vez');
  const [reminders, setReminders] = useState<Omit<GoalReminder, 'id' | 'notificationHistory' | 'lastNotified'>[]>([
    { time: '09:00', message: 'Recordatorio de tu meta', recurrence: 'daily', enabled: true }
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title || target < 1 || reminders.length === 0) {
      alert('Por favor completa todos los campos requeridos');
      return;
    }

    const fullReminders: GoalReminder[] = reminders.map((r, index) => ({
      ...r,
      id: `${Date.now()}-${index}`,
      notificationHistory: []
    }));

    onAddGoal({
      title,
      description,
      category,
      color,
      icon,
      progress: 0,
      target,
      unit,
      reminders: fullReminders,
      enabled: true
    });

    // Reset form
    setTitle('');
    setDescription('');
    setCategory('Salud');
    setColor('#8b5cf6');
    setIcon('🎯');
    setTarget(1);
    setUnit('vez');
    setReminders([{ time: '09:00', message: 'Recordatorio de tu meta', recurrence: 'daily', enabled: true }]);
  };

  const addReminder = () => {
    setReminders([...reminders, { 
      time: '12:00', 
      message: 'Recordatorio de tu meta', 
      recurrence: 'daily',
      enabled: true 
    }]);
  };

  const updateReminder = (index: number, updates: Partial<Omit<GoalReminder, 'id' | 'notificationHistory' | 'lastNotified'>>) => {
    const updated = [...reminders];
    updated[index] = { ...updated[index], ...updates };
    setReminders(updated);
  };

  const removeReminder = (index: number) => {
    if (reminders.length > 1) {
      setReminders(reminders.filter((_, i) => i !== index));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Title */}
      <div>
        <label htmlFor="title" className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
          <Type className="w-4 h-4" />
          Nombre de la meta *
        </label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Ej: Beber 8 vasos de agua"
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
          maxLength={50}
        />
      </div>

      {/* Description */}
      <div>
        <label htmlFor="description" className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
          <AlignLeft className="w-4 h-4" />
          Descripción
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="¿Qué quieres lograr?"
          rows={2}
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none resize-none"
          maxLength={150}
        />
      </div>

      {/* Icon Selection */}
      <div>
        <label className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
          <Palette className="w-4 h-4" />
          Ícono
        </label>
        <div className="grid grid-cols-8 gap-2">
          {ICONS.map(i => (
            <button
              key={i}
              type="button"
              onClick={() => setIcon(i)}
              className={`aspect-square flex items-center justify-center text-2xl p-2 rounded-xl transition-all hover:scale-110 ${
                icon === i 
                  ? 'bg-purple-500 ring-2 ring-purple-300 scale-110' 
                  : 'bg-white/10 hover:bg-white/20'
              }`}
            >
              {i}
            </button>
          ))}
        </div>
      </div>

      {/* Category and Color */}
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="category" className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
            <Tag className="w-4 h-4" />
            Categoría
          </label>
          <select
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none appearance-none"
          >
            {CATEGORIES.map(cat => (
              <option key={cat} value={cat} className="bg-slate-800">{cat}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
            <Palette className="w-4 h-4" />
            Color
          </label>
          <div className="grid grid-cols-4 gap-2">
            {COLORS.map(c => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={`h-12 rounded-xl transition-all ${
                  color === c 
                    ? 'ring-2 ring-white scale-110' 
                    : 'hover:scale-105'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Target and Unit */}
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="target" className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
            <Target className="w-4 h-4" />
            Meta diaria *
          </label>
          <input
            type="number"
            id="target"
            value={target}
            onChange={(e) => setTarget(Math.max(1, parseInt(e.target.value) || 1))}
            min="1"
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
          />
        </div>

        <div>
          <label htmlFor="unit" className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
            <Hash className="w-4 h-4" />
            Unidad
          </label>
          <input
            type="text"
            id="unit"
            value={unit}
            onChange={(e) => setUnit(e.target.value)}
            placeholder="Ej: vasos, minutos, páginas"
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
            maxLength={20}
          />
        </div>
      </div>

      {/* Reminders */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="flex items-center gap-2 text-sm font-semibold text-white">
            <Clock className="w-4 h-4" />
            Recordatorios ({reminders.length})
          </label>
          <button
            type="button"
            onClick={addReminder}
            className="text-purple-300 hover:text-white text-sm font-medium flex items-center gap-1"
          >
            <Plus className="w-4 h-4" />
            Agregar
          </button>
        </div>

        <div className="space-y-3">
          {reminders.map((reminder, index) => (
            <div key={index} className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="grid md:grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-xs text-purple-300 mb-1 block">Hora</label>
                  <input
                    type="time"
                    value={reminder.time}
                    onChange={(e) => updateReminder(index, { time: e.target.value })}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-purple-300 mb-1 block">Frecuencia</label>
                  <select
                    value={reminder.recurrence}
                    onChange={(e) => updateReminder(index, { recurrence: e.target.value as any })}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm focus:ring-2 focus:ring-purple-500 outline-none appearance-none"
                  >
                    <option value="daily" className="bg-slate-800">Diario</option>
                    <option value="weekly" className="bg-slate-800">Semanal</option>
                    <option value="monthly" className="bg-slate-800">Mensual</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={reminder.message}
                  onChange={(e) => updateReminder(index, { message: e.target.value })}
                  placeholder="Mensaje del recordatorio"
                  className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm placeholder-purple-300 focus:ring-2 focus:ring-purple-500 outline-none"
                  maxLength={100}
                />
                {reminders.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeReminder(index)}
                    className="px-3 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-4 rounded-xl font-bold text-lg transition-all shadow-xl hover:shadow-2xl hover:scale-[1.02]"
      >
        Crear Meta
      </button>
    </form>
  );
}