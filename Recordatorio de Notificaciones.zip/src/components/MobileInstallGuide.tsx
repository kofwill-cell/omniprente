import { useState } from 'react';
import { Smartphone, Download, CheckCircle, Share, Menu, Home, Chrome, Globe } from 'lucide-react';

export function MobileInstallGuide() {
  const [deviceType, setDeviceType] = useState<'android' | 'iphone' | null>(null);
  const [currentStep, setCurrentStep] = useState(0);

  const androidSteps = [
    {
      title: "Paso 1: Abre Chrome en tu Android",
      icon: <Chrome className="w-8 h-8" />,
      instructions: [
        "Abre la app de Chrome en tu celular Android",
        "Asegúrate de tener la URL de esta app (cópiala desde la computadora)",
        "Pega la URL en Chrome móvil"
      ],
      emoji: "📱"
    },
    {
      title: "Paso 2: Busca el menú (los 3 puntos)",
      icon: <Menu className="w-8 h-8" />,
      instructions: [
        "Cuando la app cargue, busca los 3 puntos verticales (⋮) en la esquina superior derecha",
        "Toca los 3 puntos para abrir el menú",
        "Se abrirá un menú con varias opciones"
      ],
      emoji: "⋮"
    },
    {
      title: "Paso 3: Selecciona 'Instalar app' o 'Agregar a Inicio'",
      icon: <Download className="w-8 h-8" />,
      instructions: [
        "Busca la opción que dice 'Instalar app' o 'Agregar a pantalla de inicio'",
        "Puede aparecer un banner en la parte inferior también",
        "Toca esa opción"
      ],
      emoji: "⬇️"
    },
    {
      title: "Paso 4: Confirma la instalación",
      icon: <CheckCircle className="w-8 h-8" />,
      instructions: [
        "Aparecerá un popup preguntando si quieres instalar",
        "Verás el nombre 'Mis Metas' y el ícono 🎯",
        "Toca 'Instalar' o 'Agregar'"
      ],
      emoji: "✅"
    },
    {
      title: "Paso 5: ¡Listo! Abre la app",
      icon: <Home className="w-8 h-8" />,
      instructions: [
        "La app ahora está en tu pantalla de inicio",
        "Busca el ícono 🎯 'Mis Metas'",
        "Tócalo para abrir la app como si fuera nativa",
        "¡Ahora ve a Ajustes y activa las notificaciones!"
      ],
      emoji: "🎉"
    }
  ];

  const iphoneSteps = [
    {
      title: "Paso 1: IMPORTANTE - Solo funciona en Safari",
      icon: <Globe className="w-8 h-8" />,
      instructions: [
        "⚠️ En iPhone, PWAs SOLO funcionan en Safari (NO en Chrome)",
        "Abre Safari en tu iPhone",
        "Copia la URL de esta app desde tu computadora",
        "Pega la URL en Safari móvil"
      ],
      emoji: "🌐"
    },
    {
      title: "Paso 2: Busca el botón 'Compartir'",
      icon: <Share className="w-8 h-8" />,
      instructions: [
        "Cuando la app cargue, busca el botón de Compartir (📤) en la parte inferior",
        "Está en el centro o esquina inferior del navegador Safari",
        "Es un cuadrado con una flecha hacia arriba",
        "Tócalo para abrir el menú de compartir"
      ],
      emoji: "📤"
    },
    {
      title: "Paso 3: Desplázate hacia abajo en el menú",
      icon: <Download className="w-8 h-8" />,
      instructions: [
        "Se abrirá un menú grande con muchas opciones",
        "Desplázate HACIA ABAJO en ese menú",
        "Busca la opción 'Agregar a pantalla de inicio' (tiene un ícono de +)",
        "Es diferente a 'Agregar marcador'"
      ],
      emoji: "⬇️"
    },
    {
      title: "Paso 4: Personaliza y agrega",
      icon: <CheckCircle className="w-8 h-8" />,
      instructions: [
        "Aparecerá una pantalla de confirmación",
        "Verás el nombre 'Mis Metas' (puedes cambiarlo si quieres)",
        "Verás el ícono 🎯",
        "Toca 'Agregar' en la esquina superior derecha"
      ],
      emoji: "✅"
    },
    {
      title: "Paso 5: ¡Listo! Abre la app",
      icon: <Home className="w-8 h-8" />,
      instructions: [
        "La app ahora está en tu pantalla de inicio como cualquier app",
        "Busca el ícono 🎯 'Mis Metas'",
        "Tócalo para abrir",
        "¡Ahora ve a Ajustes y activa las notificaciones!",
        "⚠️ Las notificaciones solo funcionan si la app está INSTALADA (no desde el navegador)"
      ],
      emoji: "🎉"
    }
  ];

  const steps = deviceType === 'android' ? androidSteps : deviceType === 'iphone' ? iphoneSteps : [];

  if (!deviceType) {
    return (
      <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 backdrop-blur-xl rounded-3xl shadow-2xl p-8 border-2 border-purple-500/30">
        <div className="text-center mb-8">
          <div className="inline-block p-4 bg-purple-500/20 rounded-2xl mb-4">
            <Smartphone className="w-16 h-16 text-purple-300" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-3">
            📱 Instalar en tu Celular
          </h2>
          <p className="text-purple-200 text-lg">
            Sigue esta guía paso a paso para instalar la app como si fuera nativa
          </p>
        </div>

        <div className="space-y-4">
          <p className="text-center text-white font-medium mb-6">
            ¿Qué celular tienes?
          </p>

          <button
            onClick={() => setDeviceType('android')}
            className="w-full bg-green-600 hover:bg-green-700 text-white px-8 py-6 rounded-2xl text-xl font-bold transition-all transform hover:scale-105 flex items-center justify-center gap-4 shadow-lg"
          >
            <span className="text-4xl">🤖</span>
            <span>Android (Samsung, Xiaomi, Huawei, etc.)</span>
          </button>

          <button
            onClick={() => setDeviceType('iphone')}
            className="w-full bg-gray-800 hover:bg-gray-900 text-white px-8 py-6 rounded-2xl text-xl font-bold transition-all transform hover:scale-105 flex items-center justify-center gap-4 shadow-lg"
          >
            <span className="text-4xl">🍎</span>
            <span>iPhone (iOS)</span>
          </button>
        </div>

        <div className="mt-8 p-5 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
          <p className="text-sm text-yellow-200 flex items-start gap-2">
            <span className="text-2xl">⚠️</span>
            <span>
              <strong className="text-yellow-100">Importante:</strong> Esta guía es para instalar la app en tu celular. 
              Si estás en la computadora, copia la URL de esta página y ábrela en el navegador de tu celular.
            </span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border-2 border-purple-500/30">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/20 rounded-xl">
            {deviceType === 'android' ? '🤖' : '🍎'}
          </div>
          <h3 className="text-xl font-bold text-white">
            Guía para {deviceType === 'android' ? 'Android' : 'iPhone'}
          </h3>
        </div>
        <button
          onClick={() => {
            setDeviceType(null);
            setCurrentStep(0);
          }}
          className="text-purple-300 hover:text-white text-sm underline"
        >
          Cambiar dispositivo
        </button>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <span className="text-sm text-purple-300">Progreso</span>
          <span className="text-sm font-bold text-white">{currentStep + 1} / {steps.length}</span>
        </div>
        <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
          <div
            className="bg-gradient-to-r from-purple-500 to-pink-500 h-full transition-all duration-500 rounded-full"
            style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Current Step */}
      <div className="bg-white/5 rounded-2xl p-6 border border-white/10 mb-6 min-h-[400px]">
        <div className="flex items-center gap-4 mb-6">
          <div className="p-4 bg-purple-500/20 rounded-xl text-purple-300">
            {steps[currentStep].icon}
          </div>
          <div className="flex-1">
            <div className="text-5xl mb-2">{steps[currentStep].emoji}</div>
            <h4 className="text-xl font-bold text-white">
              {steps[currentStep].title}
            </h4>
          </div>
        </div>

        <div className="space-y-4">
          {steps[currentStep].instructions.map((instruction, index) => (
            <div key={index} className="flex items-start gap-3 bg-white/5 rounded-xl p-4">
              <div className="flex-shrink-0 w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                {index + 1}
              </div>
              <p className="text-purple-100 flex-1 leading-relaxed">
                {instruction}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex gap-3">
        {currentStep > 0 && (
          <button
            onClick={() => setCurrentStep(currentStep - 1)}
            className="flex-1 bg-white/10 hover:bg-white/20 text-white px-6 py-4 rounded-xl font-semibold transition-colors"
          >
            ← Anterior
          </button>
        )}
        
        {currentStep < steps.length - 1 ? (
          <button
            onClick={() => setCurrentStep(currentStep + 1)}
            className="flex-1 bg-purple-600 hover:bg-purple-700 text-white px-6 py-4 rounded-xl font-semibold transition-colors"
          >
            Siguiente →
          </button>
        ) : (
          <button
            onClick={() => {
              setDeviceType(null);
              setCurrentStep(0);
            }}
            className="flex-1 bg-green-600 hover:bg-green-700 text-white px-6 py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            ¡Completado!
          </button>
        )}
      </div>

      {/* Quick Tips */}
      <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
        <p className="text-sm text-blue-200">
          💡 <strong className="text-blue-100">Tip:</strong> {
            deviceType === 'android' 
              ? 'Si no ves la opción "Instalar app", busca un banner en la parte inferior de la pantalla con el botón "Agregar".'
              : 'Si no encuentras "Agregar a pantalla de inicio", asegúrate de estar en Safari (NO Chrome) y desplázate más abajo en el menú de compartir.'
          }
        </p>
      </div>
    </div>
  );
}
