import { useState } from 'react';
import { ReminderForm } from './ReminderForm';
import { ReminderCard } from './ReminderCard';
import { Plus, Search, Filter } from 'lucide-react';
import type { Reminder } from '../App';

interface ReminderManagerProps {
  reminders: Reminder[];
  onAddReminder: (reminder: Omit<Reminder, 'id' | 'notificationHistory' | 'lastNotified'>) => void;
  onUpdateReminder: (id: string, updates: Partial<Reminder>) => void;
  onDeleteReminder: (id: string) => void;
}

export function ReminderManager({ 
  reminders, 
  onAddReminder, 
  onUpdateReminder,
  onDeleteReminder 
}: ReminderManagerProps) {
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRecurrence, setFilterRecurrence] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const handleAddReminder = (reminder: Omit<Reminder, 'id' | 'notificationHistory' | 'lastNotified'>) => {
    onAddReminder(reminder);
    setShowForm(false);
  };

  // Filtrar recordatorios
  const filteredReminders = reminders.filter(reminder => {
    const matchesSearch = reminder.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         reminder.message.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRecurrence = filterRecurrence === 'all' || reminder.recurrence === filterRecurrence;
    const matchesCategory = filterCategory === 'all' || reminder.category === filterCategory;
    
    return matchesSearch && matchesRecurrence && matchesCategory;
  });

  // Obtener categorías únicas
  const categories = Array.from(new Set(reminders.map(r => r.category)));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Recordatorios</h1>
        <p className="text-gray-600">Gestiona tus recordatorios recurrentes</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl shadow-lg p-4">
        <div className="grid md:grid-cols-3 gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar recordatorios..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
            />
          </div>

          {/* Filter by Recurrence */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <select
              value={filterRecurrence}
              onChange={(e) => setFilterRecurrence(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none appearance-none bg-white"
            >
              <option value="all">Todas las frecuencias</option>
              <option value="once">Una vez</option>
              <option value="daily">Diario</option>
              <option value="weekly">Semanal</option>
              <option value="monthly">Mensual</option>
            </select>
          </div>

          {/* Filter by Category */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none appearance-none bg-white"
            >
              <option value="all">Todas las categorías</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Add Button */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-6 py-4 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
      >
        <Plus className="w-6 h-6" />
        Crear Nuevo Recordatorio
      </button>

      {/* Form Modal */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Nuevo Recordatorio</h2>
            <button
              onClick={() => setShowForm(false)}
              className="text-gray-400 hover:text-gray-600 text-2xl font-light"
            >
              ×
            </button>
          </div>
          <ReminderForm onAddReminder={handleAddReminder} />
        </div>
      )}

      {/* Reminders List */}
      <div className="space-y-4">
        {filteredReminders.length > 0 ? (
          filteredReminders.map(reminder => (
            <ReminderCard
              key={reminder.id}
              reminder={reminder}
              onUpdate={onUpdateReminder}
              onDelete={onDeleteReminder}
            />
          ))
        ) : (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="text-gray-400 mb-4">
              <Plus className="w-16 h-16 mx-auto opacity-30" />
            </div>
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              No hay recordatorios
            </h3>
            <p className="text-gray-500">
              {searchQuery || filterRecurrence !== 'all' || filterCategory !== 'all'
                ? 'No se encontraron resultados con los filtros aplicados'
                : 'Crea tu primer recordatorio para comenzar'}
            </p>
          </div>
        )}
      </div>

      {/* Summary */}
      {filteredReminders.length > 0 && (
        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-4 text-center">
          <p className="text-gray-700">
            Mostrando <span className="font-bold text-purple-600">{filteredReminders.length}</span> de{' '}
            <span className="font-bold">{reminders.length}</span> recordatorios
          </p>
        </div>
      )}
    </div>
  );
}
