import { Smartphone, Download, Bell, CheckCircle } from 'lucide-react';

export function AndroidPWAInstructions() {
  return (
    <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border-2 border-green-500/30">
      <div className="flex items-start gap-4 mb-6">
        <div className="p-3 bg-green-500/30 rounded-xl">
          <Smartphone className="w-8 h-8 text-green-300" />
        </div>
        <div>
          <h3 className="font-bold text-white text-xl mb-2">
            📱 Android Chrome Detectado
          </h3>
          <p className="text-green-200 text-sm">
            Para que funcionen las notificaciones, instala la app como PWA
          </p>
        </div>
      </div>

      <div className="bg-black/20 rounded-xl p-5 mb-6">
        <h4 className="font-bold text-white mb-4 flex items-center gap-2">
          <Download className="w-5 h-5 text-green-400" />
          Cómo instalar como PWA en Android:
        </h4>
        
        <div className="space-y-4">
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500/30 flex items-center justify-center text-white font-bold">
              1
            </div>
            <div>
              <p className="text-white font-semibold mb-1">Abre el menú de Chrome</p>
              <p className="text-green-200 text-sm">Toca los 3 puntos (⋮) en la esquina superior derecha</p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500/30 flex items-center justify-center text-white font-bold">
              2
            </div>
            <div>
              <p className="text-white font-semibold mb-1">Busca "Agregar a pantalla de inicio"</p>
              <p className="text-green-200 text-sm">O "Instalar aplicación" (depende de la versión de Chrome)</p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500/30 flex items-center justify-center text-white font-bold">
              3
            </div>
            <div>
              <p className="text-white font-semibold mb-1">Toca "Agregar" o "Instalar"</p>
              <p className="text-green-200 text-sm">Se creará un icono en tu pantalla de inicio</p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500/30 flex items-center justify-center text-white font-bold">
              4
            </div>
            <div>
              <p className="text-white font-semibold mb-1">Abre la app desde tu pantalla de inicio</p>
              <p className="text-green-200 text-sm">NO desde Chrome, sino desde el icono que se creó</p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500/30 flex items-center justify-center text-white font-bold">
              5
            </div>
            <div>
              <p className="text-white font-semibold mb-1">Activa las notificaciones nuevamente</p>
              <p className="text-green-200 text-sm">Una vez dentro de la PWA, ve a Ajustes y activa las notificaciones</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-green-500/10 border-2 border-green-500/30 rounded-xl p-4 mb-4">
        <div className="flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-white font-semibold mb-2">¿Por qué es necesario instalar como PWA?</p>
            <p className="text-green-200 text-sm">
              Android Chrome requiere que la aplicación esté instalada como PWA para que el Service Worker funcione correctamente. 
              Una vez instalada, las notificaciones aparecerán en tu bandeja igual que cualquier otra app.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-yellow-500/10 border-2 border-yellow-500/30 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <Bell className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-white font-semibold mb-2">Alternativa temporal</p>
            <p className="text-yellow-200 text-sm">
              Si no puedes instalar como PWA ahora mismo, las notificaciones no funcionarán en Android Chrome 
              desde el navegador normal. Esta es una limitación del navegador, no de la aplicación.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
