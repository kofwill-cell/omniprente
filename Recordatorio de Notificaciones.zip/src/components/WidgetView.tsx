import { useState } from 'react';
import { 
  Plus, Minus, Check, Clock, Bell, ChevronRight, 
  Zap, Target, TrendingUp, Calendar
} from 'lucide-react';
import type { Goal } from '../App';

interface WidgetViewProps {
  goals: Goal[];
  onUpdateProgress: (goalId: string, newProgress: number) => void;
  onUpdateGoal: (id: string, updates: Partial<Goal>) => void;
}

export function WidgetView({ goals, onUpdateProgress, onUpdateGoal }: WidgetViewProps) {
  const [expandedGoal, setExpandedGoal] = useState<string | null>(null);

  const activeGoals = goals.filter(g => g.enabled);
  const today = new Date().toLocaleDateString('es-ES', { 
    weekday: 'long', 
    day: 'numeric', 
    month: 'long' 
  });

  const getNextReminder = (goal: Goal) => {
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5);
    
    const upcomingReminders = goal.reminders
      .filter(r => r.enabled && r.time > currentTime)
      .sort((a, b) => a.time.localeCompare(b.time));
    
    return upcomingReminders[0];
  };

  const getTotalCompletedToday = () => {
    return activeGoals.filter(g => g.progress >= g.target).length;
  };

  const getTotalProgress = () => {
    const total = activeGoals.reduce((sum, g) => sum + g.target, 0);
    const completed = activeGoals.reduce((sum, g) => sum + g.progress, 0);
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  };

  return (
    <div className="space-y-6">
      {/* Header Widget */}
      <div className="bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 rounded-3xl shadow-2xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-sm opacity-90 mb-1">Hoy es</div>
            <div className="text-xl font-bold capitalize">{today}</div>
          </div>
          <div className="bg-white/20 backdrop-blur rounded-full p-3">
            <Target className="w-8 h-8" />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mt-6">
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4 text-center">
            <div className="text-3xl font-bold">{activeGoals.length}</div>
            <div className="text-xs opacity-90 mt-1">Metas activas</div>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4 text-center">
            <div className="text-3xl font-bold">{getTotalCompletedToday()}</div>
            <div className="text-xs opacity-90 mt-1">Completadas</div>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4 text-center">
            <div className="text-3xl font-bold">{getTotalProgress()}%</div>
            <div className="text-xs opacity-90 mt-1">Progreso</div>
          </div>
        </div>
      </div>

      {/* Goals Widgets */}
      <div className="space-y-4">
        {activeGoals.length > 0 ? (
          activeGoals.map((goal) => {
            const progressPercentage = (goal.progress / goal.target) * 100;
            const isCompleted = goal.progress >= goal.target;
            const nextReminder = getNextReminder(goal);
            const isExpanded = expandedGoal === goal.id;

            return (
              <div
                key={goal.id}
                className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-xl overflow-hidden border border-white/20 transition-all hover:scale-[1.02]"
              >
                {/* Main Widget Content */}
                <div className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    {/* Icon */}
                    <div 
                      className="text-5xl flex-shrink-0 w-16 h-16 flex items-center justify-center rounded-2xl"
                      style={{ backgroundColor: `${goal.color}30` }}
                    >
                      {goal.icon}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <h3 className="text-xl font-bold text-white mb-1">
                            {goal.title}
                          </h3>
                          <p className="text-sm text-purple-200">
                            {goal.description}
                          </p>
                        </div>
                        {isCompleted && (
                          <div className="bg-green-500 rounded-full p-2">
                            <Check className="w-5 h-5 text-white" />
                          </div>
                        )}
                      </div>

                      {/* Next Reminder */}
                      {nextReminder && !isCompleted && (
                        <div className="flex items-center gap-2 text-xs text-purple-300 bg-white/5 rounded-lg px-3 py-2 mt-2">
                          <Bell className="w-3 h-3" />
                          <span>Próximo recordatorio: {nextReminder.time}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-white font-medium">
                        {goal.progress} / {goal.target} {goal.unit}
                      </span>
                      <span className="text-purple-300 font-bold">
                        {Math.round(progressPercentage)}%
                      </span>
                    </div>
                    <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500 ease-out"
                        style={{
                          width: `${Math.min(progressPercentage, 100)}%`,
                          backgroundColor: goal.color
                        }}
                      />
                    </div>
                  </div>

                  {/* Controls */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onUpdateProgress(goal.id, goal.progress - 1)}
                      disabled={goal.progress <= 0}
                      className="flex-1 bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed text-white px-4 py-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2"
                    >
                      <Minus className="w-5 h-5" />
                    </button>

                    <button
                      onClick={() => onUpdateProgress(goal.id, goal.progress + 1)}
                      disabled={goal.progress >= goal.target}
                      className="flex-[2] hover:scale-105 disabled:opacity-30 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg"
                      style={{ backgroundColor: goal.color }}
                    >
                      <Plus className="w-5 h-5" />
                      <span>Agregar</span>
                    </button>

                    <button
                      onClick={() => setExpandedGoal(isExpanded ? null : goal.id)}
                      className="flex-1 bg-white/10 hover:bg-white/20 text-white px-4 py-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2"
                    >
                      <ChevronRight className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Expanded Reminders */}
                {isExpanded && (
                  <div className="border-t border-white/10 p-6 bg-black/20">
                    <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Recordatorios ({goal.reminders.filter(r => r.enabled).length})
                    </h4>
                    <div className="space-y-2">
                      {goal.reminders
                        .filter(r => r.enabled)
                        .sort((a, b) => a.time.localeCompare(b.time))
                        .map(reminder => (
                          <div
                            key={reminder.id}
                            className="bg-white/5 rounded-lg p-3 flex items-center justify-between"
                          >
                            <div className="flex items-center gap-3">
                              <div className="bg-purple-500/30 rounded-lg p-2">
                                <Bell className="w-4 h-4 text-purple-300" />
                              </div>
                              <div>
                                <div className="text-white font-medium text-sm">
                                  {reminder.time}
                                </div>
                                <div className="text-purple-300 text-xs">
                                  {reminder.message}
                                </div>
                              </div>
                            </div>
                            <div className="text-xs text-purple-300">
                              {reminder.notificationHistory.length} enviados
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-xl p-12 text-center border border-white/20">
            <div className="text-6xl mb-4">🎯</div>
            <h3 className="text-2xl font-bold text-white mb-2">
              No hay metas activas
            </h3>
            <p className="text-purple-300 mb-6">
              Ve a la sección "Metas" para crear tus primeros objetivos
            </p>
          </div>
        )}
      </div>

      {/* Quick Stats Widget */}
      {activeGoals.length > 0 && (
        <div className="bg-gradient-to-br from-blue-500 via-cyan-500 to-teal-500 rounded-3xl shadow-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-6 h-6" />
            <h3 className="text-lg font-bold">Racha de Hoy</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/20 backdrop-blur rounded-2xl p-4">
              <TrendingUp className="w-6 h-6 mb-2" />
              <div className="text-2xl font-bold">
                {activeGoals.reduce((sum, g) => sum + g.reminders.reduce((s, r) => s + r.notificationHistory.length, 0), 0)}
              </div>
              <div className="text-xs opacity-90 mt-1">Total de recordatorios enviados</div>
            </div>
            <div className="bg-white/20 backdrop-blur rounded-2xl p-4">
              <Calendar className="w-6 h-6 mb-2" />
              <div className="text-2xl font-bold">
                {activeGoals.reduce((sum, g) => sum + g.reminders.filter(r => r.enabled).length, 0)}
              </div>
              <div className="text-xs opacity-90 mt-1">Recordatorios activos</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
