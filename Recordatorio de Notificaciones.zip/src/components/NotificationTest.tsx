import { useState } from 'react';
import { Bell, CheckCircle, XCircle, AlertCircle, Smartphone, Monitor, HelpCircle } from 'lucide-react';
import { UnblockNotifications } from './UnblockNotifications';

interface NotificationTestProps {
  permission: NotificationPermission;
  onRequestPermission: () => void;
  onSendTest: () => void;
}

export function NotificationTest({ permission, onRequestPermission, onSendTest }: NotificationTestProps) {
  const [showHelp, setShowHelp] = useState(false);

  const getCurrentTime = () => {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  const getTestTime = () => {
    const now = new Date();
    now.setMinutes(now.getMinutes() + 2);
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  return (
    <div className="space-y-4">
      {/* Status Card */}
      <div className={`rounded-2xl p-6 border-2 ${
        permission === 'granted' 
          ? 'bg-green-500/10 border-green-500/30' 
          : permission === 'denied'
          ? 'bg-red-500/10 border-red-500/30'
          : 'bg-yellow-500/10 border-yellow-500/30'
      }`}>
        <div className="flex items-start gap-4">
          <div className={`p-3 rounded-xl ${
            permission === 'granted' 
              ? 'bg-green-500/20' 
              : permission === 'denied'
              ? 'bg-red-500/20'
              : 'bg-yellow-500/20'
          }`}>
            {permission === 'granted' ? (
              <CheckCircle className="w-6 h-6 text-green-400" />
            ) : permission === 'denied' ? (
              <XCircle className="w-6 h-6 text-red-400" />
            ) : (
              <AlertCircle className="w-6 h-6 text-yellow-400" />
            )}
          </div>
          
          <div className="flex-1">
            <h3 className="font-bold text-white mb-1">
              {permission === 'granted' 
                ? '✅ Notificaciones Activadas' 
                : permission === 'denied'
                ? '❌ Notificaciones Bloqueadas'
                : '⚠️ Notificaciones Desactivadas'}
            </h3>
            <p className="text-sm text-purple-300 mb-3">
              {permission === 'granted' 
                ? 'Estás listo para recibir recordatorios de tus metas' 
                : permission === 'denied'
                ? 'Debes habilitar las notificaciones desde la configuración del navegador'
                : 'Necesitas activar las notificaciones para recibir recordatorios'}
            </p>

            <div className="flex flex-wrap gap-2">
              {permission !== 'granted' && (
                <button
                  onClick={onRequestPermission}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                  Activar Ahora
                </button>
              )}

              {permission === 'granted' && (
                <button
                  onClick={onSendTest}
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                >
                  <Bell className="w-4 h-4" />
                  Enviar Prueba
                </button>
              )}

              <button
                onClick={() => setShowHelp(!showHelp)}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
              >
                <HelpCircle className="w-4 h-4" />
                Ayuda
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Help Section */}
      {showHelp && (
        <div className="bg-white/5 backdrop-blur rounded-2xl p-6 border border-white/10">
          <h4 className="font-semibold text-white mb-4 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-purple-400" />
            Guía de Prueba Rápida
          </h4>

          <div className="space-y-4">
            {/* Step 1 */}
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                1
              </div>
              <div>
                <h5 className="font-medium text-white mb-1">Activar Notificaciones</h5>
                <p className="text-sm text-purple-300">
                  Haz clic en "Activar Ahora" y acepta cuando el navegador te pida permiso.
                  Deberías recibir una notificación de confirmación.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                2
              </div>
              <div>
                <h5 className="font-medium text-white mb-1">Enviar Notificación de Prueba</h5>
                <p className="text-sm text-purple-300">
                  Haz clic en "Enviar Prueba" para verificar que las notificaciones funcionan.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                3
              </div>
              <div>
                <h5 className="font-medium text-white mb-1">Crear Meta de Prueba</h5>
                <p className="text-sm text-purple-300 mb-2">
                  Ve a "Metas" → "Crear Nueva Meta" y configura un recordatorio para dentro de 2 minutos:
                </p>
                <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                  <div className="text-xs text-purple-400 mb-1">Hora actual: <span className="font-mono text-white">{getCurrentTime()}</span></div>
                  <div className="text-xs text-purple-400">Pon el recordatorio en: <span className="font-mono text-green-400">{getTestTime()}</span></div>
                </div>
              </div>
            </div>

            {/* Device Specific Tips */}
            <div className="border-t border-white/10 pt-4 mt-4">
              <h5 className="font-medium text-white mb-3">💡 Tips por Dispositivo</h5>
              
              <div className="space-y-2">
                <div className="flex items-start gap-2 text-sm">
                  <Monitor className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div className="text-purple-300">
                    <span className="font-medium text-white">Computadora:</span> Mantén la pestaña abierta en segundo plano
                  </div>
                </div>
                
                <div className="flex items-start gap-2 text-sm">
                  <Smartphone className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div className="text-purple-300">
                    <span className="font-medium text-white">iPhone:</span> Instala como PWA desde Safari → Compartir → "Agregar a pantalla de inicio"
                  </div>
                </div>
                
                <div className="flex items-start gap-2 text-sm">
                  <Smartphone className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div className="text-purple-300">
                    <span className="font-medium text-white">Android:</span> Chrome → Menú (⋮) → "Instalar app"
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Troubleshooting */}
      {permission === 'denied' && (
        <UnblockNotifications />
      )}
    </div>
  );
}