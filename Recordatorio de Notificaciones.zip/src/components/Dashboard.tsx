import { useMemo } from 'react';
import { 
  BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { 
  TrendingUp, Bell, CheckCircle, Calendar, 
  Activity, Target, Award, Zap 
} from 'lucide-react';
import type { Goal } from '../App';

interface DashboardProps {
  goals: Goal[];
}

export function Dashboard({ goals }: DashboardProps) {
  const stats = useMemo(() => {
    const total = goals.length;
    const active = goals.filter(g => g.enabled).length;
    const totalNotifications = goals.reduce((sum, g) => 
      sum + g.reminders.reduce((s, r) => s + r.notificationHistory.length, 0), 0
    );
    
    // Notificaciones por categoría
    const byCategory = goals.reduce((acc, g) => {
      const notifCount = g.reminders.reduce((sum, r) => sum + r.notificationHistory.length, 0);
      acc[g.category] = (acc[g.category] || 0) + notifCount;
      return acc;
    }, {} as Record<string, number>);

    // Progreso por meta
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return date.toISOString().split('T')[0];
    });

    const notificationsByDay = last7Days.map(date => {
      const count = goals.reduce((sum, g) => {
        const dayNotifications = g.reminders.reduce((s, r) => 
          s + r.notificationHistory.filter(n => n.startsWith(date)).length, 0
        );
        return sum + dayNotifications;
      }, 0);

      const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
      const dayName = dayNames[new Date(date).getDay()];
      
      return {
        day: dayName,
        notificaciones: count
      };
    });

    // Metas completadas vs incompletas
    const completed = goals.filter(g => g.progress >= g.target).length;
    const incomplete = goals.filter(g => g.progress < g.target).length;

    // Tasa de cumplimiento promedio
    const avgCompletion = goals.length > 0
      ? Math.round(goals.reduce((sum, g) => sum + (g.progress / g.target), 0) / goals.length * 100)
      : 0;

    return {
      total,
      active,
      totalNotifications,
      byCategory,
      notificationsByDay,
      completed,
      incomplete,
      avgCompletion
    };
  }, [goals]);

  const categoryData = Object.entries(stats.byCategory).map(([name, value]) => ({
    name,
    value
  }));

  const completionData = [
    { name: 'Completadas', value: stats.completed, color: '#10b981' },
    { name: 'En progreso', value: stats.incomplete, color: '#f59e0b' }
  ].filter(d => d.value > 0);

  const COLORS = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899'];

  // Top metas más activas
  const topGoals = [...goals]
    .map(g => ({
      ...g,
      totalNotifications: g.reminders.reduce((sum, r) => sum + r.notificationHistory.length, 0)
    }))
    .sort((a, b) => b.totalNotifications - a.totalNotifications)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-2">Estadísticas</h1>
        <p className="text-purple-300">Análisis de tus metas y progreso</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-5 text-white shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <Target className="w-8 h-8 opacity-80" />
            <TrendingUp className="w-5 h-5 opacity-80" />
          </div>
          <div className="text-3xl font-bold mb-1">{stats.total}</div>
          <div className="text-purple-100 text-sm">Metas totales</div>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-5 text-white shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-8 h-8 opacity-80" />
            <Activity className="w-5 h-5 opacity-80" />
          </div>
          <div className="text-3xl font-bold mb-1">{stats.active}</div>
          <div className="text-blue-100 text-sm">Activas</div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-5 text-white shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <Zap className="w-8 h-8 opacity-80" />
            <Bell className="w-5 h-5 opacity-80" />
          </div>
          <div className="text-3xl font-bold mb-1">{stats.totalNotifications}</div>
          <div className="text-green-100 text-sm">Notificaciones</div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-5 text-white shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <Award className="w-8 h-8 opacity-80" />
            <Calendar className="w-5 h-5 opacity-80" />
          </div>
          <div className="text-3xl font-bold mb-1">{stats.avgCompletion}%</div>
          <div className="text-orange-100 text-sm">Cumplimiento</div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Line Chart - Notificaciones por día */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/20">
          <h3 className="text-lg font-semibold text-white mb-4">
            Actividad de los últimos 7 días
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={stats.notificationsByDay}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis 
                dataKey="day" 
                stroke="#a78bfa"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="#a78bfa"
                style={{ fontSize: '12px' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b',
                  border: '1px solid #334155',
                  borderRadius: '8px',
                  fontSize: '12px',
                  color: '#fff'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="notificaciones" 
                stroke="#8b5cf6" 
                strokeWidth={3}
                dot={{ fill: '#8b5cf6', r: 5 }}
                activeDot={{ r: 7 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Pie Chart - Por categoría */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/20">
          <h3 className="text-lg font-semibold text-white mb-4">
            Notificaciones por categoría
          </h3>
          {categoryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1e293b',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-purple-300">
              No hay datos disponibles
            </div>
          )}
        </div>

        {/* Bar Chart - Completadas vs Incompletas */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/20">
          <h3 className="text-lg font-semibold text-white mb-4">
            Estado de las metas
          </h3>
          {completionData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={completionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
                <XAxis 
                  dataKey="name" 
                  stroke="#a78bfa"
                  style={{ fontSize: '12px' }}
                />
                <YAxis 
                  stroke="#a78bfa"
                  style={{ fontSize: '12px' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1e293b',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff'
                  }}
                />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {completionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-purple-300">
              No hay metas aún
            </div>
          )}
        </div>

        {/* Top Metas */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/20">
          <h3 className="text-lg font-semibold text-white mb-4">
            Top 5 Metas Más Activas
          </h3>
          <div className="space-y-3">
            {topGoals.length > 0 ? (
              topGoals.map((goal, index) => (
                <div 
                  key={goal.id}
                  className="flex items-center gap-3 p-3 bg-white/5 rounded-xl"
                >
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                    style={{ backgroundColor: `${goal.color}30` }}
                  >
                    {goal.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-white text-sm truncate">
                      {goal.title}
                    </div>
                    <div className="text-xs text-purple-300">
                      {goal.category}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-purple-400 text-sm">
                      {goal.totalNotifications}
                    </div>
                    <div className="text-xs text-purple-300">enviadas</div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-purple-300">
                No hay metas aún
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Insights */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl shadow-xl p-6 text-white">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <TrendingUp className="w-6 h-6" />
          Resumen
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="text-2xl font-bold mb-1">
              {stats.active > 0 ? Math.round(stats.totalNotifications / stats.active) : 0}
            </div>
            <div className="text-purple-100 text-sm">
              Promedio de notificaciones por meta
            </div>
          </div>
          
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="text-2xl font-bold mb-1">
              {categoryData.length}
            </div>
            <div className="text-purple-100 text-sm">
              Categorías diferentes
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="text-2xl font-bold mb-1">
              {stats.completed}
            </div>
            <div className="text-purple-100 text-sm">
              Metas completadas hoy
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}