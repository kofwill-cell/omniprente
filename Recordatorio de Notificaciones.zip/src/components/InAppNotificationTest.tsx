import { Bell, Zap } from 'lucide-react';

interface InAppNotificationTestProps {
  onTest: () => void;
}

export function InAppNotificationTest({ onTest }: InAppNotificationTestProps) {
  return (
    <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border-2 border-orange-500/30">
      <div className="flex items-start gap-4 mb-6">
        <div className="p-3 bg-orange-500/30 rounded-xl">
          <Zap className="w-8 h-8 text-orange-300" />
        </div>
        <div>
          <h3 className="font-bold text-white text-xl mb-2">
            🎯 Prueba de Notificaciones IN-APP
          </h3>
          <p className="text-orange-200 text-sm">
            Sistema alternativo que funciona SIN Service Worker
          </p>
        </div>
      </div>

      <div className="bg-black/20 rounded-xl p-5 mb-4">
        <h4 className="font-bold text-white mb-3">✨ Características:</h4>
        <ul className="space-y-2 text-orange-200 text-sm">
          <li className="flex items-start gap-2">
            <span className="text-green-400 flex-shrink-0">✓</span>
            <span>Notificaciones flotantes dentro de la app</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-400 flex-shrink-0">✓</span>
            <span>Sonido y vibración incluidos</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-400 flex-shrink-0">✓</span>
            <span>Funciona en Android Chrome SIN instalación</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-400 flex-shrink-0">✓</span>
            <span>No necesita Service Worker</span>
          </li>
        </ul>
      </div>

      <button
        onClick={onTest}
        className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-4 rounded-xl font-bold text-lg shadow-xl hover:shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3"
      >
        <Bell className="w-6 h-6" />
        🎉 PROBAR NOTIFICACIÓN IN-APP
      </button>

      <p className="text-orange-300 text-xs mt-4 text-center">
        Presiona el botón y verás una notificación flotante en la parte superior de la pantalla
      </p>
    </div>
  );
}
