import { useEffect, useState } from 'react';

export function NotificationDebugger() {
  const [logs, setLogs] = useState<string[]>([]);
  const [swStatus, setSwStatus] = useState<string>('Verificando...');

  useEffect(() => {
    // Verificar Service Worker
    const checkSW = async () => {
      if ('serviceWorker' in navigator) {
        try {
          const registration = await navigator.serviceWorker.getRegistration();
          if (registration) {
            if (registration.active) {
              setSwStatus('✅ Activo y funcionando');
            } else if (registration.installing) {
              setSwStatus('⏳ Instalando...');
            } else if (registration.waiting) {
              setSwStatus('⏳ Esperando activación...');
            } else {
              setSwStatus('⚠️ Registrado pero no activo');
            }
          } else {
            setSwStatus('❌ No registrado');
          }
        } catch (error) {
          setSwStatus('❌ Error al verificar');
        }
      } else {
        setSwStatus('❌ No disponible en este navegador');
      }
    };

    checkSW();

    // Capturar logs de consola
    const originalLog = console.log;
    const originalError = console.error;
    const originalWarn = console.warn;

    console.log = (...args) => {
      originalLog(...args);
      setLogs(prev => [...prev.slice(-20), `[LOG] ${args.join(' ')}`]);
    };

    console.error = (...args) => {
      originalError(...args);
      setLogs(prev => [...prev.slice(-20), `[ERROR] ${args.join(' ')}`]);
    };

    console.warn = (...args) => {
      originalWarn(...args);
      setLogs(prev => [...prev.slice(-20), `[WARN] ${args.join(' ')}`]);
    };

    return () => {
      console.log = originalLog;
      console.error = originalError;
      console.warn = originalWarn;
    };
  }, []);

  return (
    <div className="space-y-4">
      {/* Service Worker Status */}
      <div className="p-4 bg-white/5 rounded-lg border border-white/10">
        <div className="font-medium text-white mb-2">Estado del Service Worker:</div>
        <div className="text-sm text-purple-300">{swStatus}</div>
      </div>

      {/* Console Logs */}
      <div className="bg-black/30 rounded-lg p-4 font-mono text-xs max-h-96 overflow-y-auto">
        {logs.length === 0 ? (
          <div className="text-gray-500 text-center py-4">
            Esperando logs... Presiona "Activar Ahora" o "Enviar Prueba"
          </div>
        ) : (
          logs.map((log, i) => (
            <div
              key={i}
              className={`py-1 ${
                log.includes('[ERROR]')
                  ? 'text-red-400'
                  : log.includes('[WARN]')
                  ? 'text-yellow-400'
                  : log.includes('✅')
                  ? 'text-green-400'
                  : 'text-gray-300'
              }`}
            >
              {log}
            </div>
          ))
        )}
      </div>

      {/* Quick Actions */}
      <div className="flex gap-2">
        <button
          onClick={() => setLogs([])}
          className="flex-1 bg-white/10 text-white px-3 py-2 rounded-lg text-sm hover:bg-white/20 transition-colors"
        >
          Limpiar Consola
        </button>
        <button
          onClick={() => window.location.reload()}
          className="flex-1 bg-purple-600 text-white px-3 py-2 rounded-lg text-sm hover:bg-purple-700 transition-colors"
        >
          Recargar App
        </button>
      </div>
    </div>
  );
}