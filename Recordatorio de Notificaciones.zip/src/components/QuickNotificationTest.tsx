import { useState } from 'react';
import { Bell, Smartphone, Monitor, Zap } from 'lucide-react';

export function QuickNotificationTest() {
  const [testResult, setTestResult] = useState<string>('');

  const testDirectNotification = async () => {
    setTestResult('⚠️ Método directo no disponible en este dispositivo. Usa Service Worker.');
    
    // NO USAR new Notification() - Causa error en móvil
    // En su lugar, siempre usar Service Worker
    await testServiceWorkerNotification();
  };

  const testServiceWorkerNotification = async () => {
    setTestResult('Probando notificación...');
    try {
      if (Notification.permission !== 'granted') {
        setTestResult('❌ Permisos no concedidos');
        return;
      }

      // Intentar primero con Service Worker
      let success = false;
      
      if ('serviceWorker' in navigator) {
        try {
          const registration = await navigator.serviceWorker.ready;
          await registration.showNotification('🔔 Prueba de Notificación', {
            body: 'Si ves esto en tu bandeja, ¡funciona!',
            icon: '/icon-192.png',
            badge: '/icon-192.png',
            vibrate: [200, 100, 200],
            tag: 'test-sw'
          });
          setTestResult('✅ Notificación enviada via Service Worker\n\nRevisa tu bandeja de notificaciones (desliza desde arriba en móvil)');
          success = true;
        } catch (swError: any) {
          console.warn('Service Worker falló:', swError);
        }
      }
      
      // Si Service Worker falló, intentar método directo
      if (!success) {
        try {
          new Notification('🔔 Prueba de Notificación', {
            body: 'Si ves esto en tu bandeja, ¡funciona!',
            icon: '/icon-192.png',
            tag: 'test-direct'
          });
          setTestResult('✅ Notificación enviada via método directo\n\nRevisa tu bandeja de notificaciones');
        } catch (directError: any) {
          setTestResult(`❌ No se pudo enviar: ${directError.message}\n\n⚠️ Puede que tu navegador/dispositivo no soporte notificaciones en este contexto.`);
        }
      }

    } catch (error: any) {
      setTestResult(`❌ Error: ${error.message}`);
    }
  };

  const testBothMethods = async () => {
    setTestResult('Probando notificaciones...');
    
    if (Notification.permission !== 'granted') {
      setTestResult('❌ Permisos no concedidos');
      return;
    }

    let results: string[] = [];

    // Primera notificación
    try {
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification('🚀 Prueba 1', {
          body: 'Primera notificación de prueba',
          icon: '/icon-192.png',
          tag: 'test-both-1'
        });
        results.push('✅ Notificación 1 enviada');
      }
    } catch (error: any) {
      results.push(`❌ Notificación 1 falló: ${error.message}`);
    }

    // Esperar 2 segundos
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Segunda notificación
    try {
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification('🎯 Prueba 2', {
          body: 'Segunda notificación de prueba',
          icon: '/icon-192.png',
          tag: 'test-both-2'
        });
        results.push('✅ Notificación 2 enviada');
      }
    } catch (error: any) {
      results.push(`❌ Notificación 2 falló: ${error.message}`);
    }

    setTestResult(results.join('\n') + '\n\nSi no las ves, revisa el centro de notificaciones.');
  };

  return (
    <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border-2 border-purple-500/30">
      <div className="flex items-start gap-4 mb-6">
        <div className="p-3 bg-purple-500/30 rounded-xl">
          <Zap className="w-8 h-8 text-purple-300" />
        </div>
        <div>
          <h3 className="font-bold text-white text-xl mb-2">
            🧪 Prueba Rápida de Notificaciones
          </h3>
          <p className="text-purple-200 text-sm">
            Prueba el sistema de notificaciones en tu dispositivo
          </p>
        </div>
      </div>

      <div className="grid gap-3 mb-6">
        <button
          onClick={testServiceWorkerNotification}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-3 text-lg"
        >
          <Bell className="w-6 h-6" />
          Enviar 1 Notificación
        </button>

        <button
          onClick={testBothMethods}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white px-6 py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-3 text-lg"
        >
          <Bell className="w-6 h-6" />
          Enviar 2 Notificaciones (con delay)
        </button>
      </div>

      {testResult && (
        <div className={`p-4 rounded-xl border-2 ${
          testResult.includes('✅') 
            ? 'bg-green-500/10 border-green-500/30' 
            : testResult.includes('❌')
            ? 'bg-red-500/10 border-red-500/30'
            : 'bg-blue-500/10 border-blue-500/30'
        }`}>
          <div className="font-mono text-sm whitespace-pre-wrap text-white">
            {testResult}
          </div>
        </div>
      )}

      <div className="mt-6 p-4 bg-purple-500/10 rounded-xl border border-purple-500/30">
        <h5 className="font-semibold text-white mb-2 flex items-center gap-2">
          💡 Nota Importante
        </h5>
        <ul className="text-sm text-purple-200 space-y-2">
          <li className="flex gap-2">
            <span className="text-purple-400">•</span>
            <span>Este sistema usa <strong className="text-white">Service Worker</strong> que funciona en todos los dispositivos</span>
          </li>
          <li className="flex gap-2">
            <span className="text-purple-400">•</span>
            <span>Las notificaciones aparecen en el <strong className="text-white">centro de notificaciones</strong> de tu dispositivo</span>
          </li>
          <li className="flex gap-2">
            <span className="text-purple-400">•</span>
            <span>Si no las ves inmediatamente, desliza hacia abajo (móvil) o mira la bandeja de notificaciones (desktop)</span>
          </li>
        </ul>
      </div>
    </div>
  );
}