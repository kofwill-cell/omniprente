import { useState } from 'react';
import { 
  Trash2, Calendar, Clock, Tag, Repeat, 
  MoreVertical, Edit2, TrendingUp, Bell, BellOff 
} from 'lucide-react';
import type { Reminder } from '../App';

interface ReminderCardProps {
  reminder: Reminder;
  onUpdate: (id: string, updates: Partial<Reminder>) => void;
  onDelete: (id: string) => void;
}

export function ReminderCard({ reminder, onUpdate, onDelete }: ReminderCardProps) {
  const [showMenu, setShowMenu] = useState(false);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('es-ES', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const getRecurrenceLabel = (recurrence: string) => {
    const labels = {
      once: 'Una vez',
      daily: 'Diario',
      weekly: 'Semanal',
      monthly: 'Mensual'
    };
    return labels[recurrence as keyof typeof labels] || recurrence;
  };

  const handleToggle = () => {
    onUpdate(reminder.id, { enabled: !reminder.enabled });
  };

  const handleDelete = () => {
    if (confirm(`¿Estás seguro de que quieres eliminar "${reminder.title}"?`)) {
      onDelete(reminder.id);
    }
  };

  return (
    <div 
      className={`bg-white rounded-2xl shadow-lg overflow-hidden transition-all ${
        !reminder.enabled ? 'opacity-60' : ''
      }`}
    >
      {/* Color Bar */}
      <div 
        className="h-2"
        style={{ backgroundColor: reminder.color }}
      />

      <div className="p-5">
        <div className="flex items-start gap-4">
          {/* Color Circle */}
          <div 
            className="w-12 h-12 rounded-full flex items-center justify-center text-white flex-shrink-0"
            style={{ backgroundColor: reminder.color }}
          >
            <Bell className="w-6 h-6" />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="text-lg font-bold text-gray-900">
                {reminder.title}
              </h3>
              
              {/* Menu Button */}
              <div className="relative">
                <button
                  onClick={() => setShowMenu(!showMenu)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>

                {showMenu && (
                  <>
                    <div 
                      className="fixed inset-0 z-10"
                      onClick={() => setShowMenu(false)}
                    />
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-200 py-1 z-20">
                      <button
                        onClick={() => {
                          handleToggle();
                          setShowMenu(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                      >
                        {reminder.enabled ? <BellOff className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
                        {reminder.enabled ? 'Desactivar' : 'Activar'}
                      </button>
                      <button
                        onClick={() => {
                          handleDelete();
                          setShowMenu(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Eliminar
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>

            {reminder.message && (
              <p className="text-gray-600 text-sm mb-3">
                {reminder.message}
              </p>
            )}

            {/* Meta Information */}
            <div className="flex flex-wrap gap-3 mb-3">
              <div className="flex items-center gap-1.5 text-sm text-gray-600 bg-gray-50 px-3 py-1.5 rounded-lg">
                <Tag className="w-4 h-4" />
                <span>{reminder.category}</span>
              </div>

              <div className="flex items-center gap-1.5 text-sm text-gray-600 bg-gray-50 px-3 py-1.5 rounded-lg">
                <Repeat className="w-4 h-4" />
                <span>{getRecurrenceLabel(reminder.recurrence)}</span>
              </div>

              <div className="flex items-center gap-1.5 text-sm text-gray-600 bg-gray-50 px-3 py-1.5 rounded-lg">
                <Clock className="w-4 h-4" />
                <span>{reminder.time}</span>
              </div>

              {reminder.recurrence === 'once' && (
                <div className="flex items-center gap-1.5 text-sm text-gray-600 bg-gray-50 px-3 py-1.5 rounded-lg">
                  <Calendar className="w-4 h-4" />
                  <span>{formatDate(reminder.startDate)}</span>
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="flex items-center gap-4 pt-3 border-t border-gray-100">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-500" />
                <span className="text-sm text-gray-600">
                  <span className="font-semibold text-gray-900">
                    {reminder.notificationHistory.length}
                  </span> notificaciones enviadas
                </span>
              </div>

              {reminder.lastNotified && (
                <div className="text-xs text-gray-500">
                  Última: {new Date(reminder.lastNotified).toLocaleDateString('es-ES')}
                </div>
              )}
            </div>

            {/* Status Badge */}
            <div className="mt-3">
              <span 
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
                  reminder.enabled 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {reminder.enabled ? (
                  <>
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    Activo
                  </>
                ) : (
                  <>
                    <div className="w-2 h-2 bg-gray-400 rounded-full" />
                    Inactivo
                  </>
                )}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
