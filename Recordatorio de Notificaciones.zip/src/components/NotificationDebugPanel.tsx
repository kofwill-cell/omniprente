import { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { AndroidPWAInstructions } from './AndroidPWAInstructions';

export function NotificationDebugPanel() {
  const [status, setStatus] = useState({
    notificationAPI: false,
    permission: 'default',
    serviceWorker: false,
    swRegistration: false,
    swActive: false,
    isSecureContext: false,
    isPWA: false,
    isMobile: false,
    isAndroid: false
  });

  const [testLog, setTestLog] = useState<string[]>([]);
  const [showAndroidInstructions, setShowAndroidInstructions] = useState(false);

  const checkStatus = async () => {
    const isAndroid = /Android/i.test(navigator.userAgent);
    
    const newStatus: any = {
      notificationAPI: 'Notification' in window,
      permission: Notification.permission,
      serviceWorker: 'serviceWorker' in navigator,
      swRegistration: false,
      swActive: false,
      isSecureContext: window.isSecureContext,
      isPWA: window.matchMedia('(display-mode: standalone)').matches,
      isMobile: /Android|iPhone|iPad/i.test(navigator.userAgent),
      isAndroid: isAndroid
    };

    // Verificar Service Worker
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.getRegistration();
        newStatus.swRegistration = !!registration;
        newStatus.swActive = !!(registration && registration.active);
      } catch (e) {
        console.error('Error al verificar SW:', e);
      }
    }

    setStatus(newStatus);
    
    // Mostrar instrucciones si es Android sin PWA y sin SW activo
    if (isAndroid && !newStatus.isPWA && !newStatus.swActive) {
      setShowAndroidInstructions(true);
    }
  };

  useEffect(() => {
    checkStatus();
  }, []);

  const testNotificationDirect = async () => {
    const log: string[] = [];
    
    log.push('🧪 === INICIANDO PRUEBA DIRECTA ===');
    log.push(`📱 Dispositivo: ${status.isMobile ? 'Móvil' : 'Desktop'}`);
    log.push(`🔐 Contexto seguro: ${status.isSecureContext ? 'Sí' : 'No'}`);
    log.push(`🏠 PWA instalada: ${status.isPWA ? 'Sí' : 'No'}`);
    log.push(`✅ Permiso: ${status.permission}`);

    if (status.permission !== 'granted') {
      log.push('❌ ERROR: No tienes permisos de notificación');
      setTestLog(log);
      return;
    }

    let success = false;

    // Método 1: Service Worker
    if ('serviceWorker' in navigator) {
      try {
        log.push('🔄 Método 1: Intentando con Service Worker...');
        const registration = await navigator.serviceWorker.ready;
        log.push('✅ Service Worker está listo');

        log.push('🔔 Llamando a showNotification...');
        
        await registration.showNotification('🔔 PRUEBA DIRECTA', {
          body: 'Si ves esto en tu bandeja de notificaciones, ¡FUNCIONA!',
          icon: '/icon-192.png',
          badge: '/icon-192.png',
          vibrate: [300, 100, 300],
          tag: 'test-' + Date.now(),
          requireInteraction: false,
          silent: false,
          timestamp: Date.now()
        });

        log.push('✅✅✅ NOTIFICACIÓN ENVIADA CON ÉXITO (Service Worker) ✅✅✅');
        success = true;
        
      } catch (error: any) {
        log.push(`⚠️ Service Worker falló: ${error.message}`);
      }
    } else {
      log.push('⚠️ Service Worker no disponible');
    }

    // Método 2: Notificación directa (fallback)
    if (!success) {
      try {
        log.push('🔄 Método 2: Intentando notificación directa...');
        
        new Notification('🔔 PRUEBA DIRECTA', {
          body: 'Si ves esto en tu bandeja de notificaciones, ¡FUNCIONA!',
          icon: '/icon-192.png',
          tag: 'test-direct-' + Date.now()
        });

        log.push('✅✅✅ NOTIFICACIÓN ENVIADA CON ÉXITO (Directo) ✅✅✅');
        success = true;
        
      } catch (error: any) {
        log.push(`❌ Notificación directa falló: ${error.message}`);
      }
    }

    if (success) {
      log.push('');
      log.push('👀 REVISA TU BANDEJA DE NOTIFICACIONES:');
      log.push('   - Móvil: Desliza desde arriba');
      log.push('   - Desktop: Mira la esquina de la pantalla');
    } else {
      log.push('');
      log.push('❌ AMBOS MÉTODOS FALLARON');
      log.push('Tu navegador o dispositivo puede no soportar notificaciones en este contexto.');
    }

    setTestLog(log);
  };

  const StatusIcon = ({ ok }: { ok: boolean }) => 
    ok ? <CheckCircle className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />;

  return (
    <>
      {/* Instrucciones para Android - PRIMERO Y MÁS VISIBLE */}
      {showAndroidInstructions && (
        <div className="mb-6">
          <AndroidPWAInstructions />
        </div>
      )}

      <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-3xl shadow-2xl p-6 border-2 border-blue-500/30">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-8 h-8 text-blue-300" />
            <h3 className="font-bold text-white text-xl">🔍 Diagnóstico Completo</h3>
          </div>
          <button
            onClick={checkStatus}
            className="p-2 bg-blue-500/30 rounded-lg hover:bg-blue-500/50 transition-colors"
          >
            <RefreshCw className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Estado del Sistema */}
        <div className="space-y-2 mb-6 bg-black/20 rounded-xl p-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Notification API</span>
            <StatusIcon ok={status.notificationAPI} />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Permiso de Notificaciones</span>
            <span className={`font-semibold ${
              status.permission === 'granted' ? 'text-green-400' : 
              status.permission === 'denied' ? 'text-red-400' : 'text-yellow-400'
            }`}>
              {status.permission}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Service Worker Disponible</span>
            <StatusIcon ok={status.serviceWorker} />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Service Worker Registrado</span>
            <StatusIcon ok={status.swRegistration} />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Service Worker Activo</span>
            <StatusIcon ok={status.swActive} />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Contexto Seguro (HTTPS)</span>
            <StatusIcon ok={status.isSecureContext} />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Instalada como PWA</span>
            <StatusIcon ok={status.isPWA} />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-white">Dispositivo Móvil</span>
            <StatusIcon ok={status.isMobile} />
          </div>
        </div>

        {/* Botón de Prueba */}
        <button
          onClick={testNotificationDirect}
          disabled={status.permission !== 'granted'}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-6 py-4 rounded-xl font-bold text-lg transition-colors mb-4"
        >
          �� PRUEBA DIRECTA DE NOTIFICACIÓN
        </button>

        {/* Log de Prueba */}
        {testLog.length > 0 && (
          <div className="bg-black/30 rounded-xl p-4 font-mono text-xs max-h-64 overflow-y-auto">
            {testLog.map((line, i) => (
              <div
                key={i}
                className={`py-1 ${
                  line.includes('❌') || line.includes('ERROR')
                    ? 'text-red-400 font-bold'
                    : line.includes('✅') || line.includes('ÉXITO')
                    ? 'text-green-400 font-bold'
                    : line.includes('⚠️') || line.includes('ADVERTENCIA')
                    ? 'text-yellow-400'
                    : line.includes('👀') || line.includes('REVISA')
                    ? 'text-cyan-400 font-bold'
                    : 'text-gray-300'
                }`}
              >
                {line}
              </div>
            ))}
          </div>
        )}

        {/* Advertencias */}
        {status.permission !== 'granted' && (
          <div className="mt-4 p-4 bg-red-500/20 border-2 border-red-500/50 rounded-xl">
            <p className="text-red-200 text-sm font-semibold">
              ⚠️ Primero activa las notificaciones con el botón "Activar Ahora"
            </p>
          </div>
        )}

        {!status.isSecureContext && (
          <div className="mt-4 p-4 bg-red-500/20 border-2 border-red-500/50 rounded-xl">
            <p className="text-red-200 text-sm font-semibold">
              ⚠️ No estás en un contexto seguro (HTTPS). Las notificaciones no funcionarán.
            </p>
          </div>
        )}
      </div>
    </>
  );
}