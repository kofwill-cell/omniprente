import { useEffect, useState } from 'react';
import { X, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface InAppNotificationData {
  id: string;
  title: string;
  body: string;
  timestamp: number;
  icon?: string;
}

interface InAppNotificationProps {
  notification: InAppNotificationData;
  onClose: (id: string) => void;
}

export function InAppNotification({ notification, onClose }: InAppNotificationProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Auto-cerrar después de 8 segundos
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(() => onClose(notification.id), 300);
    }, 8000);

    return () => clearTimeout(timer);
  }, [notification.id, onClose]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(() => onClose(notification.id), 300);
  };

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -100, scale: 0.8 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -50, scale: 0.8 }}
      className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl shadow-2xl p-4 mb-3 border-2 border-white/20 backdrop-blur-xl"
      style={{ maxWidth: '400px', width: '90vw' }}
    >
      <div className="flex items-start gap-3">
        {/* Icono */}
        <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
          {notification.icon ? (
            <span className="text-2xl">{notification.icon}</span>
          ) : (
            <Bell className="w-6 h-6 text-white" />
          )}
        </div>

        {/* Contenido */}
        <div className="flex-1 min-w-0">
          <h4 className="font-bold text-white text-lg mb-1 truncate">
            {notification.title}
          </h4>
          <p className="text-white/90 text-sm leading-snug">
            {notification.body}
          </p>
          <p className="text-white/60 text-xs mt-2">
            {new Date(notification.timestamp).toLocaleTimeString('es-ES', {
              hour: '2-digit',
              minute: '2-digit'
            })}
          </p>
        </div>

        {/* Botón cerrar */}
        <button
          onClick={handleClose}
          className="flex-shrink-0 w-8 h-8 rounded-lg bg-white/20 hover:bg-white/30 transition-colors flex items-center justify-center"
        >
          <X className="w-5 h-5 text-white" />
        </button>
      </div>
    </motion.div>
  );
}

interface InAppNotificationContainerProps {
  notifications: InAppNotificationData[];
  onCloseNotification: (id: string) => void;
}

export function InAppNotificationContainer({ 
  notifications, 
  onCloseNotification 
}: InAppNotificationContainerProps) {
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] pointer-events-none">
      <div className="pointer-events-auto">
        <AnimatePresence mode="popLayout">
          {notifications.map((notification) => (
            <InAppNotification
              key={notification.id}
              notification={notification}
              onClose={onCloseNotification}
            />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
