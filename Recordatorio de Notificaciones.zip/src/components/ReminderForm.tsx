import { useState } from 'react';
import { Calendar, Clock, Type, AlignLeft, Tag, Palette, Repeat } from 'lucide-react';
import type { Reminder } from '../App';

interface ReminderFormProps {
  onAddReminder: (reminder: Omit<Reminder, 'id' | 'notificationHistory' | 'lastNotified'>) => void;
}

const CATEGORIES = [
  'Salud',
  'Trabajo',
  'Personal',
  'Estudio',
  'Ejercicio',
  'Finanzas',
  'Familia',
  'Otro'
];

const COLORS = [
  { name: 'Púrpura', value: '#8b5cf6' },
  { name: 'Azul', value: '#3b82f6' },
  { name: 'Verde', value: '#10b981' },
  { name: 'Naranja', value: '#f59e0b' },
  { name: 'Rojo', value: '#ef4444' },
  { name: 'Rosa', value: '#ec4899' },
  { name: 'Índigo', value: '#6366f1' },
  { name: 'Turquesa', value: '#14b8a6' },
];

export function ReminderForm({ onAddReminder }: ReminderFormProps) {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState('Salud');
  const [color, setColor] = useState('#8b5cf6');
  const [recurrence, setRecurrence] = useState<'once' | 'daily' | 'weekly' | 'monthly'>('daily');
  const [startDate, setStartDate] = useState('');
  const [time, setTime] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title || !startDate || !time) {
      alert('Por favor completa todos los campos requeridos');
      return;
    }

    const reminderDateTime = new Date(`${startDate}T${time}`);
    const now = new Date();
    
    if (recurrence === 'once' && reminderDateTime <= now) {
      alert('Para recordatorios únicos, la fecha debe ser futura');
      return;
    }

    onAddReminder({
      title,
      message,
      category,
      color,
      recurrence,
      startDate,
      time,
      enabled: true,
    });

    // Reset form
    setTitle('');
    setMessage('');
    setCategory('Salud');
    setColor('#8b5cf6');
    setRecurrence('daily');
    setStartDate('');
    setTime('');
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Title */}
      <div>
        <label htmlFor="title" className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
          <Type className="w-4 h-4" />
          Título del recordatorio *
        </label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Ej: Tomar vitaminas"
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
          maxLength={50}
        />
      </div>

      {/* Message */}
      <div>
        <label htmlFor="message" className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
          <AlignLeft className="w-4 h-4" />
          Mensaje (opcional)
        </label>
        <textarea
          id="message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Mensaje adicional que aparecerá en la notificación"
          rows={3}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all resize-none"
          maxLength={200}
        />
      </div>

      {/* Category */}
      <div>
        <label htmlFor="category" className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
          <Tag className="w-4 h-4" />
          Categoría
        </label>
        <select
          id="category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all appearance-none bg-white"
        >
          {CATEGORIES.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      {/* Color */}
      <div>
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
          <Palette className="w-4 h-4" />
          Color del recordatorio
        </label>
        <div className="grid grid-cols-4 gap-3">
          {COLORS.map(c => (
            <button
              key={c.value}
              type="button"
              onClick={() => setColor(c.value)}
              className={`h-12 rounded-lg transition-all ${
                color === c.value 
                  ? 'ring-4 ring-offset-2 scale-105' 
                  : 'hover:scale-105'
              }`}
              style={{ 
                backgroundColor: c.value,
                ringColor: c.value
              }}
              title={c.name}
            />
          ))}
        </div>
      </div>

      {/* Recurrence */}
      <div>
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
          <Repeat className="w-4 h-4" />
          Frecuencia
        </label>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setRecurrence('once')}
            className={`px-4 py-3 rounded-xl font-medium transition-all ${
              recurrence === 'once'
                ? 'bg-purple-600 text-white shadow-lg'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Una vez
          </button>
          <button
            type="button"
            onClick={() => setRecurrence('daily')}
            className={`px-4 py-3 rounded-xl font-medium transition-all ${
              recurrence === 'daily'
                ? 'bg-purple-600 text-white shadow-lg'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Diario
          </button>
          <button
            type="button"
            onClick={() => setRecurrence('weekly')}
            className={`px-4 py-3 rounded-xl font-medium transition-all ${
              recurrence === 'weekly'
                ? 'bg-purple-600 text-white shadow-lg'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Semanal
          </button>
          <button
            type="button"
            onClick={() => setRecurrence('monthly')}
            className={`px-4 py-3 rounded-xl font-medium transition-all ${
              recurrence === 'monthly'
                ? 'bg-purple-600 text-white shadow-lg'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Mensual
          </button>
        </div>
      </div>

      {/* Date and Time */}
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="startDate" className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
            <Calendar className="w-4 h-4" />
            Fecha de inicio *
          </label>
          <input
            type="date"
            id="startDate"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            min={today}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
          />
        </div>

        <div>
          <label htmlFor="time" className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
            <Clock className="w-4 h-4" />
            Hora *
          </label>
          <input
            type="time"
            id="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
          />
        </div>
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-6 py-4 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl"
      >
        Crear Recordatorio
      </button>
    </form>
  );
}
