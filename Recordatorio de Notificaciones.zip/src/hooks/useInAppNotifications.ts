import { useState, useCallback } from 'react';
import { InAppNotificationData } from '../components/InAppNotification';

// Sonido de notificación (usando Web Audio API)
const playNotificationSound = () => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Tono de notificación agradable
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (error) {
    console.warn('No se pudo reproducir sonido:', error);
  }
};

// Vibración
const vibrateDevice = () => {
  if ('vibrate' in navigator) {
    try {
      navigator.vibrate([200, 100, 200]);
    } catch (error) {
      console.warn('No se pudo vibrar:', error);
    }
  }
};

export function useInAppNotifications() {
  const [notifications, setNotifications] = useState<InAppNotificationData[]>([]);

  const showNotification = useCallback((title: string, body: string, icon?: string) => {
    const notification: InAppNotificationData = {
      id: `notification-${Date.now()}-${Math.random()}`,
      title,
      body,
      timestamp: Date.now(),
      icon
    };

    // Agregar notificación
    setNotifications(prev => [notification, ...prev]);

    // Reproducir sonido
    playNotificationSound();

    // Vibrar
    vibrateDevice();

    console.log('📱 Notificación in-app mostrada:', title);

    return notification.id;
  }, []);

  const closeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  return {
    notifications,
    showNotification,
    closeNotification,
    clearAll
  };
}
