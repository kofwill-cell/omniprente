# 📱 GUÍA COMPLETA: INSTALAR LA APP EN TU CELULAR

## 🎯 ¿QUÉ VAS A LOGRAR?

Al final de esta guía, tendrás la app instalada en tu celular como si fuera una app nativa de la tienda, con:
- ✅ Ícono en la pantalla de inicio
- ✅ Se abre como app (sin barra del navegador)
- ✅ Notificaciones funcionando
- ✅ Funciona offline

---

## 📋 PASO 0: PREPARACIÓN (EN TU COMPUTADORA)

### Opción A: Si Figma Make te da un link para compartir
1. En Figma Make, busca el botón **"Share"** o **"Compartir"**
2. Copia el link público que te da
3. Envíate ese link a tu celular por:
   - WhatsApp (a ti mismo)
   - Email
   - Telegram
   - O cualquier app de mensajería

### Opción B: Si no encuentras opción para compartir
1. Copia la URL completa de tu navegador (la que está en la barra de direcciones)
2. Envíate esa URL a tu celular

---

## 🤖 ANDROID (Samsung, Xiaomi, Huawei, Motorola, etc.)

### Requisito: Chrome

**⚠️ IMPORTANTE:** La app debe instalarse desde **Chrome** (no desde Samsung Internet, Firefox, etc.)

### Paso 1: Abrir en Chrome
1. En tu celular Android, abre el link que te enviaste
2. Si se abre en otro navegador, cópialo y pégalo en **Chrome**

### Paso 2: Esperar a que cargue
1. Espera a que la app cargue completamente
2. Verás la pantalla principal con tus metas

### Paso 3: Instalar la app

**Opción A: Banner automático (la más fácil)**
- Si tienes suerte, aparecerá un **banner en la parte inferior** que dice:
  - "Agregar a pantalla de inicio" o "Instalar app"
- Toca ese banner
- Confirma tocando "Instalar"
- ¡Listo!

**Opción B: Menú manual**
1. Toca los **3 puntos verticales (⋮)** en la esquina superior derecha
2. Busca en el menú la opción:
   - **"Instalar app"** o
   - **"Agregar a pantalla de inicio"** o
   - **"Add to Home screen"**
3. Tócala
4. Aparecerá un popup con el nombre "Mis Metas" y el ícono 🎯
5. Toca **"Instalar"** o **"Agregar"**

### Paso 4: Verificar
1. Minimiza Chrome
2. Ve a tu pantalla de inicio
3. Busca el ícono morado con 🎯 que dice "Mis Metas"
4. ¡Ábrelo!

### Paso 5: Activar notificaciones
1. Dentro de la app, ve a **"Ajustes"** (el ícono ⚙️ abajo)
2. Toca **"Activar Ahora"** en la sección de notificaciones
3. Acepta el permiso cuando Android te pregunte
4. ✅ ¡Listo! Deberías recibir una notificación de bienvenida

---

## 🍎 iPHONE (iOS)

### Requisito: Safari (NO Chrome)

**⚠️ MUY IMPORTANTE:** En iPhone, las PWAs **SOLO funcionan en Safari**, NO en Chrome ni otros navegadores.

### Paso 1: Abrir en Safari
1. En tu iPhone, abre el link que te enviaste
2. **SI SE ABRE EN CHROME:** 
   - Copia la URL
   - Abre Safari
   - Pega la URL en Safari
3. Espera a que cargue

### Paso 2: Buscar el botón Compartir
1. En la parte **inferior de Safari**, busca el botón de **Compartir**
2. Es un **cuadrado con una flecha hacia arriba (📤)**
3. Está en el centro o esquina inferior
4. Tócalo

### Paso 3: Agregar a pantalla de inicio
1. Se abrirá un menú grande con muchas opciones
2. **Desplázate HACIA ABAJO** en ese menú
3. Busca la opción **"Agregar a pantalla de inicio"**
   - Tiene un ícono de +
   - Es DIFERENTE a "Agregar marcador"
4. Tócala

### Paso 4: Confirmar
1. Aparecerá una pantalla de confirmación
2. Verás:
   - Nombre: "Mis Metas" (puedes cambiarlo si quieres)
   - Ícono: 🎯
3. Toca **"Agregar"** en la esquina superior derecha

### Paso 5: Verificar
1. Sal de Safari (botón inicio)
2. Ve a tu pantalla de inicio
3. Busca el ícono morado con 🎯
4. Tócalo para abrir la app

### Paso 6: Activar notificaciones
1. Dentro de la app, ve a **"Ajustes"** (⚙️)
2. Toca **"Activar Ahora"**
3. Safari te preguntará si quieres permitir notificaciones
4. Toca **"Permitir"**
5. ✅ ¡Listo!

**⚠️ NOTA IMPORTANTE PARA iOS:**
- Las notificaciones web en iPhone **SOLO funcionan si la app está instalada** (no desde Safari normal)
- Asegúrate de abrir la app desde el ícono de la pantalla de inicio, NO desde Safari

---

## 🧪 PROBAR QUE TODO FUNCIONA

### 1. Probar notificaciones
1. Abre la app desde el ícono de tu pantalla de inicio
2. Ve a **Ajustes** (⚙️)
3. Toca **"Enviar Notificación de Prueba"**
4. Deberías ver una notificación que dice "🧪 Notificación de Prueba"

### 2. Crear una meta de prueba
1. Ve a **Metas** (🎯)
2. Toca **"Crear Nueva Meta"**
3. Llena el formulario:
   - Nombre: "Prueba"
   - Categoría: Cualquiera
   - Meta: 1
   - Unidad: vez
4. En "Recordatorios", configura uno para **2 minutos después de la hora actual**
   - Ejemplo: Si son las 3:15 PM, pon **15:17**
5. Guarda la meta
6. **Espera 2 minutos SIN CERRAR LA APP**
7. Deberías recibir la notificación

---

## 🚨 SOLUCIÓN DE PROBLEMAS

### ❌ No veo la opción "Instalar app" en Android

**Posibles causas:**
1. **No estás usando Chrome** → Abre el link en Chrome
2. **La app ya está instalada** → Revisa tu pantalla de inicio
3. **El navegador no detecta que es una PWA** → Recarga la página (F5)

**Solución:**
- Busca el banner en la parte inferior de la pantalla
- Si no aparece, intenta recargar la página
- Verifica que tengas Chrome actualizado

### ❌ No encuentro "Agregar a pantalla de inicio" en iPhone

**Posibles causas:**
1. **Estás usando Chrome u otro navegador** → DEBES usar Safari
2. **No estás buscando en el lugar correcto** → Es en el menú de Compartir (📤)
3. **No desplazaste hacia abajo** → El menú tiene muchas opciones, sigue bajando

**Solución:**
1. Cierra la app
2. Abre Safari
3. Pega la URL de nuevo
4. Toca el botón Compartir (📤) en la parte INFERIOR
5. Desplázate hacia abajo hasta encontrar "Agregar a pantalla de inicio"

### ❌ Las notificaciones no llegan

**En Android:**
1. Abre **Ajustes de Android** → **Apps** → **Mis Metas**
2. Ve a **Notificaciones**
3. Asegúrate de que estén **activadas**
4. También verifica en **Ajustes** → **Notificaciones** → **Permisos de apps**

**En iPhone:**
1. La app DEBE estar **instalada** (no funcionan desde Safari normal)
2. Abre **Ajustes de iOS** → **Safari** → **Notificaciones**
3. Asegúrate de que estén activadas
4. Si no aparece la opción, reinstala la app

### ❌ La app se abre en el navegador, no como app

**Esto significa que NO está instalada correctamente.**

**Solución:**
1. Borra el ícono de tu pantalla de inicio
2. Sigue los pasos de instalación de nuevo
3. Asegúrate de tocar **"Instalar"** o **"Agregar"**, NO solo crear un marcador

### ❌ En iPhone, no puedo activar notificaciones

**Causas comunes:**
1. No instalaste la app, solo creaste un marcador
2. Safari no tiene permisos de notificación a nivel del sistema

**Solución:**
1. Ve a **Ajustes de iOS** → **Safari** → **Notificaciones**
2. Activa las notificaciones
3. Reinstala la app siguiendo los pasos de arriba
4. Cuando te pregunte por permisos, toca **"Permitir"**

---

## 💡 TIPS PRO

### Para que las notificaciones funcionen mejor:

1. **Mantén la app "abierta" en segundo plano**
   - No la cierres completamente
   - Puedes minimizarla y usar otras apps

2. **Verifica que tu celular no tenga modo "ahorro de batería" agresivo**
   - Algunos celulares (Xiaomi, Huawei) tienen optimizaciones que matan apps en segundo plano
   - Ve a Ajustes → Batería → Excepciones
   - Agrega "Mis Metas" a las excepciones

3. **En iPhone, la app debe estar instalada desde Safari**
   - No funciona si la abres desde Chrome o desde Safari sin instalar

4. **Prueba con una meta de prueba**
   - Crea un recordatorio para 2 minutos después
   - Deja la app abierta (puede estar en segundo plano)
   - Espera a ver si llega la notificación

---

## 📞 ¿TODAVÍA NO FUNCIONA?

Si seguiste todos los pasos y no funciona, necesito que me digas:

1. **¿Qué celular tienes?**
   - Modelo exacto (ej: Samsung Galaxy S21, iPhone 13, etc.)
   
2. **¿Qué navegador usaste?**
   - Chrome, Safari, Samsung Internet, etc.

3. **¿En qué paso te quedaste atascado?**
   - No puedo instalar la app
   - La instalé pero no abre
   - Las notificaciones no llegan
   
4. **¿Qué ves cuando intentas instalar?**
   - Capturas de pantalla ayudan mucho

5. **¿Aparece algún mensaje de error?**
   - Anótalo textualmente

Con esa información puedo ayudarte específicamente. 🚀

---

## ✅ CHECKLIST FINAL

Marca cada paso cuando lo completes:

### Android
- [ ] Abrí el link en Chrome
- [ ] Esperé a que cargue completamente
- [ ] Vi la opción "Instalar app" o el banner
- [ ] Toqué "Instalar"
- [ ] Vi el ícono 🎯 en mi pantalla de inicio
- [ ] Abrí la app desde el ícono (no desde Chrome)
- [ ] Fui a Ajustes → Activar Notificaciones
- [ ] Acepté el permiso
- [ ] Recibí la notificación de bienvenida
- [ ] Envié notificación de prueba y funcionó
- [ ] ✅ ¡TODO LISTO!

### iPhone
- [ ] Abrí el link en Safari (NO Chrome)
- [ ] Esperé a que cargue completamente
- [ ] Toqué el botón Compartir (📤) en la parte inferior
- [ ] Desplacé hacia abajo en el menú
- [ ] Encontré "Agregar a pantalla de inicio"
- [ ] Toqué "Agregar" para confirmar
- [ ] Vi el ícono 🎯 en mi pantalla de inicio
- [ ] Abrí la app desde el ícono (no desde Safari)
- [ ] Fui a Ajustes → Activar Notificaciones
- [ ] Acepté el permiso
- [ ] Recibí la notificación de bienvenida
- [ ] Envié notificación de prueba y funcionó
- [ ] ✅ ¡TODO LISTO!

---

**¡Éxito con tu app de metas! 🎯**
